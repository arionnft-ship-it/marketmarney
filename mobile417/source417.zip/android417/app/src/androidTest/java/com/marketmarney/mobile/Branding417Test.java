package com.marketmarney.mobile;

import android.content.Context;
import android.net.Uri;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import androidx.test.platform.app.InstrumentationRegistry;
import org.junit.Test;
import java.io.InputStream;
import java.security.MessageDigest;
import java.util.Collections;
import java.util.Map;
import static org.junit.Assert.*;

/** Exercises actual offline logo delivery and its origin boundary, without network or accounts. */
public class Branding417Test {
    private static final String BASE="https://marketmarney.com";
    private static final String PATH="/__android417/brand/logo.png";
    private static WebResourceRequest request(String url,String method){
        return new WebResourceRequest(){
            public Uri getUrl(){return Uri.parse(url);}
            public boolean isForMainFrame(){return false;}
            public boolean isRedirect(){return false;}
            public boolean hasGesture(){return false;}
            public String getMethod(){return method;}
            public Map<String,String> getRequestHeaders(){return Collections.emptyMap();}
        };
    }
    private AppResources49 resolver(){
        Context context=InstrumentationRegistry.getInstrumentation().getTargetContext();
        final AppResources49[] r={null};
        InstrumentationRegistry.getInstrumentation().runOnMainSync(()->r[0]=AppResources49.install(context));
        return r[0];
    }
    @Test public void logoIsTheApprovedPngWithBinaryMime()throws Exception{
        WebResourceResponse response=resolver().respond(request(BASE+PATH+"?v=417","GET"),"test");
        assertNotNull(response);assertEquals(200,response.getStatusCode());
        assertEquals("image/png",response.getMimeType());assertNull(response.getEncoding());
        assertEquals("nosniff",response.getResponseHeaders().get("X-Content-Type-Options"));
        MessageDigest digest=MessageDigest.getInstance("SHA-256");
        try(InputStream in=response.getData()){byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1)digest.update(b,0,n);}
        StringBuilder actual=new StringBuilder();for(byte b:digest.digest())actual.append(String.format(java.util.Locale.ROOT,"%02x",b&255));
        assertEquals("17570fe09d2bdca2063645e6f0b1c7929aa29930a48f6d344fa63e5c4208867e",actual.toString());
    }
    @Test public void corporateAliasesWorkForBothRequestChannels()throws Exception{
        AppResources49 r=resolver();
        for(String path:new String[]{"/assets/brand-logo.webp","/assets/brand-logo.png","/favicon.png","/assets/apple-touch-icon.png","/assets/embedded-favicon.png","/icons/icon-192.png","/icons/icon-512.png","/marketmarney-m-logo.png"}){
            for(String channel:new String[]{"view","worker"}){
                WebResourceResponse response=r.respond(request(BASE+path+"?v=old","GET"),channel);
                assertNotNull(path,response);assertEquals("image/png",response.getMimeType());response.getData().close();
            }
        }
    }
    @Test public void brandInterceptionDoesNotWidenOriginOrPrivateDataAccess(){
        AppResources49 r=resolver();
        for(String url:new String[]{"http://marketmarney.com"+PATH,"https://marketmarney.com.evil.example"+PATH,"https://user@marketmarney.com"+PATH,"https://marketmarney.com:444"+PATH,BASE+"/uploads/user-photo.png",BASE+"/assets/unrelated.png",BASE+"/api/community/me",BASE+"/__android417/brand/../logo.png"}){
            assertNull(url,r.respond(request(url,"GET"),"test"));
        }
        assertNull(r.respond(request(BASE+PATH,"POST"),"test"));
    }
}
