/* MarketMarney 18.6.3 — visibility-aware polling and race-safe, per-recipient chat. */
(()=>{'use strict';
const nameOf1873=(u,key='username')=>String(u?.[key==='username'?'displayName':key+'DisplayName']||u?.[key]||'Trader');

 const $=id=>document.getElementById(id),wrap=$('shMessengerWrap'),button=$('shMessengerButton'),pane=$('shMessengerPane');
 if(!wrap||!button||!pane)return;
 const badge=$('shMessengerCount'),list=$('shMsgConversationList'),listView=$('shMsgListView'),chatView=$('shMsgChatView'),status=$('shMsgStatus'),host=$('shMsgMessages'),input=$('shMsgText');
 let requestedChat=new URLSearchParams(location.search).get('chat');
 if(!/^[a-z][a-z0-9_]{2,23}$/i.test(requestedChat||''))requestedChat=null;
 let open=false,active=null,filter='all',chats=[],groups=[],view=0,signature='',throughId=null,lastRead=null;
 let threadAllowed=false;
 let readJob=null,listJob=null,threadJob=null,countJob=null,timer=null,failures=0,lastCountAt=0,authEpoch=0;
 const jobs=new Set(),drafts=new Map(),draftVersions=new Map(),sending=new Set();
 const visible=()=>!document.hidden&&navigator.onLine!==false;
 const el=(tag,cls,text)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n};
 const newMessages=el('button','sh-msg-new1863','Pesan baru ↓');newMessages.type='button';newMessages.hidden=true;host.after(newMessages);
 const valid=(stamp,name=active)=>open&&view===stamp&&active===name;
 const nearBottom=()=>host.scrollHeight-host.scrollTop-host.clientHeight<64;
 function unread(n){const total=Math.max(0,Number(n)||0);badge.hidden=!total;badge.textContent=total>99?'99+':String(total);button.setAttribute('aria-label',total?'Buka pesan trader, '+total+' belum dibaca':'Buka pesan trader')}
 function revokeView(){view++;for(const job of jobs)if(job.method==='GET')job.controller.abort();signature='';throughId=null;lastRead=null;newMessages.hidden=true}
 function remember(touched=false){if(active){const value=input.value;if(touched||value!==(drafts.get(active)||''))draftVersions.set(active,(draftVersions.get(active)||0)+1);if(value)drafts.set(active,value);else drafts.delete(active)}}
 function sendState(){const busy=active&&sending.has(active);$('shMsgCompose').querySelector('button[type="submit"]').disabled=!!busy||!threadAllowed;$('shMsgCompose').setAttribute('aria-busy',String(!!busy))}
 function lock(){authEpoch++;remember();revokeView();drafts.clear();draftVersions.clear();chats=[];groups=[];input.value='';host.replaceChildren();list.replaceChildren();active=null;open=false;pane.hidden=true;wrap.hidden=true;unread(0);button.setAttribute('aria-expanded','false')}
 async function api(path,method='GET',payload){
  const controller=new AbortController(),job={method,controller};jobs.add(job);
  const timeout=setTimeout(()=>controller.abort(),15000);
  try{
   const opt={method,credentials:'same-origin',cache:'no-store',signal:controller.signal};
   if(method!=='GET'){opt.headers={'Content-Type':'application/json','X-MarketMarney-Request':'1'};opt.body=JSON.stringify(payload||{})}
   const res=await fetch('/api/trader-connect'+path,opt),data=await res.json().catch(()=>({}));
   if(!res.ok){if(res.status===401)lock();throw Object.assign(Error(data.error||'Pesan belum dapat dimuat.'),{code:res.status})}
   return data;
  }finally{clearTimeout(timeout);jobs.delete(job)}
 }
 function time(ms){if(!ms)return '';const d=new Date(Number(ms));if(!Number.isFinite(d.getTime()))return '';const diff=Math.max(0,Date.now()-d.getTime());if(diff<60000)return 'Baru';if(diff<3600000)return Math.floor(diff/60000)+' mnt';if(diff<86400000)return Math.floor(diff/3600000)+' jam';if(diff<604800000)return Math.floor(diff/86400000)+' hari';return d.toLocaleDateString('id-ID',{day:'numeric',month:'short'})}
 function avatar(name,url,isGroup=false){const a=el('span','sh-msg-avatar'+(isGroup?' is-group':''),String(name||'G').slice(0,2).toUpperCase());if(!isGroup&&typeof url==='string'&&/^\/media\/[0-9a-f-]{36}\.(png|jpg|webp)$/.test(url)){const img=el('img');img.src=url;img.alt='';a.replaceChildren(img)}return a}
 function render(){
  const q=$('shMsgSearch').value.trim().toLocaleLowerCase('id');list.replaceChildren();
  const base=filter==='groups'?groups:filter==='unread'?chats.filter(x=>x.unread>0):chats;
  const items=base.filter(x=>[x.username||x.name,x.displayName||'',x.lastMessage||'',x.bio||''].some(s=>String(s).toLocaleLowerCase('id').includes(q)));
  if(!items.length){list.append(el('p','sh-msg-empty',q?'Tidak ada obrolan yang cocok.':filter==='groups'?'Belum ada grup yang Anda ikuti.':filter==='unread'?'Semua pesan sudah dibaca.':'Belum ada percakapan. Saling mengikuti untuk mulai chat.'));return}
  for(const item of items){
   const group=filter==='groups',name=group?item.name:nameOf1873(item),row=el('button','sh-msg-row'+(!group&&item.unread?' is-unread':''));row.type='button';row.setAttribute('aria-label',(group?'Buka grup ':'Buka chat ')+name);row.append(avatar(group?name:item.username,item.avatarUrl,group));
   const meta=el('span','sh-msg-meta'),line=el('span','sh-msg-line');line.append(el('strong','',name),el('time','',time(item.lastAt)));if(!group)window.SocialIdentity1875?.badge(line.querySelector('strong'),item);meta.append(line,el('span','sh-msg-preview',(item.lastFromMe?'Anda: ':'')+(item.lastMessage||(group?item.members+' anggota':item.bio||'Mulai percakapan'))));row.append(meta);
   if(!group&&item.unread)row.append(el('span','sh-msg-unread-dot'));
   row.addEventListener('click',()=>group?location.assign('/grup-trader.html?group='+encodeURIComponent(item.id)):openChat(item.username));list.append(row);
  }
 }
 async function pollCount(){
  if(countJob||!visible())return;const job={epoch:authEpoch};countJob=job;
  try{const d=await api('/unread');if(job.epoch!==authEpoch)return;lastCountAt=Date.now();wrap.hidden=false;unread(d.unread);if(requestedChat){const name=requestedChat;requestedChat=null;setOpen(true,name)}}catch(e){if(e.name!=='AbortError'&&e.code!==401&&open)status.textContent=navigator.onLine===false?'Offline · pesan belum terkirim.':'Koneksi terputus. Mencoba memuat kembali.'}finally{if(countJob===job)countJob=null}
 }
 async function loadList(){
  if(!open||active||!visible())return;
  const stamp=view;if(listJob?.stamp===stamp)return;const job={stamp};listJob=job;
  try{
   // A group endpoint failure must not hide a valid private inbox.
   const [conv,gr]=await Promise.allSettled([api('/conversations'),api('/groups')]);
   if(!valid(stamp,null))return;
   if(conv.status==='fulfilled'){chats=conv.value.items||[];unread(conv.value.unread);failures=0}
   else if(filter!=='groups')throw conv.reason;
   if(gr.status==='fulfilled')groups=gr.value.mine||[];else if(filter==='groups')throw gr.reason;
   render();status.textContent=gr.status==='rejected'?'Daftar grup sementara belum tersedia.':'';
  }catch(e){if(valid(stamp,null)&&e.name!=='AbortError'){failures++;status.textContent=e.message;if(!chats.length)list.replaceChildren(el('p','sh-msg-empty','Koneksi bermasalah. Daftar akan dicoba kembali.'))}}
  finally{if(listJob===job)listJob=null}
 }
 function setOpen(value,recipient=null){
  remember();revokeView();open=!!value;pane.hidden=!open;button.setAttribute('aria-expanded',String(open));active=null;input.value='';sendState();status.textContent='';
  if(open){window.dispatchEvent(new Event('mm:messenger-open'));if(recipient)openChat(recipient);else{listView.hidden=false;chatView.hidden=true;render();loadList();$('shMsgSearch').focus()}}
  schedule();
 }
 function setFilter(value){filter=value;for(const tab of pane.querySelectorAll('[data-msg-filter]')){const match=tab.dataset.msgFilter===value;tab.classList.toggle('is-active',match);tab.setAttribute('aria-pressed',String(match))}render();loadList()}
 async function acknowledge(){
  if(!open||!active||!visible()||!nearBottom()||!throughId||throughId===lastRead)return;
  const stamp=view,name=active,id=throughId;if(readJob?.stamp===stamp)return;const job={stamp};readJob=job;
  try{await api('/messages/read','POST',{username:name,throughId:id});if(!valid(stamp,name))return;lastRead=id;newMessages.hidden=true;window.dispatchEvent(new Event('mm:dm-updated'))}
  catch(e){if(valid(stamp,name)&&e.name!=='AbortError'&&e.code!==401)status.textContent='Pesan tampil; status dibaca belum tersinkron.'}
  finally{if(readJob===job)readJob=null}
 }
 function renderMessages(items,initial){
  const sig=JSON.stringify(items.map(m=>[m.id,m.body,m.createdAt,m.mine]));if(sig===signature)return;
  const bottom=initial||nearBottom(),previousTop=host.scrollTop,first=host.firstElementChild?.dataset.messageId;
  // Preserve the visible anchor even when the server's latest-80 window moves.
  const anchor=[...host.children].find(n=>n.offsetTop+n.offsetHeight>=host.scrollTop),anchorId=anchor?.dataset.messageId,offset=anchor?anchor.offsetTop-host.scrollTop:0;
  signature=sig;host.replaceChildren();
  if(!items.length)host.append(el('p','sh-msg-empty','Belum ada pesan. Mulai percakapan pertama Anda.'));
  for(const m of items){const bubble=el('div','sh-msg-bubble'+(m.mine?' is-me':''),m.body);bubble.dataset.messageId=m.id;bubble.append(el('small','',time(m.createdAt)));host.append(bubble)}
  if(bottom){host.scrollTop=host.scrollHeight;newMessages.hidden=true}
  else{const target=[...host.children].find(n=>n.dataset.messageId===anchorId);host.scrollTop=target?target.offsetTop-offset:previousTop;newMessages.hidden=false}
 }
 async function refreshThread(initial=false){
  if(!open||!active||!visible())return;const stamp=view,name=active;if(threadJob?.stamp===stamp)return;const job={stamp};threadJob=job;
  try{
   const d=await api('/messages?username='+encodeURIComponent(name));if(!valid(stamp,name)||!visible())return;
   if(d.with){$('shMsgChatName').textContent=nameOf1873(d.with);window.SocialIdentity1875?.badge($('shMsgChatName'),d.with);$('shMsgChatName').title='@'+d.with.username;}
   threadAllowed=true;input.disabled=false;sendState();if(initial)input.focus({preventScroll:true});renderMessages(d.items||[],initial);throughId=d.readThroughId||null;failures=0;
   const av=$('shMsgChatAvatar');av.replaceChildren(...avatar(name,d.with?.avatarUrl).childNodes);
   status.textContent='Diperbarui '+new Date().toLocaleTimeString('id-ID',{hour:'2-digit',minute:'2-digit'});
   await acknowledge();
  }catch(e){if(!valid(stamp,name)||e.name==='AbortError')return;failures++;status.textContent=e.message;if(initial)host.replaceChildren(el('p','sh-msg-empty','Percakapan belum bisa dimuat.'));
   if(e.code===403||e.code===404){threadAllowed=false;input.disabled=true;$('shMsgCompose').querySelector('button[type="submit"]').disabled=true;status.textContent='Percakapan tidak tersedia. Periksa apakah masih saling mengikuti.'}
  }finally{if(threadJob===job)threadJob=null}
 }
 function openChat(username){
  if(!open)return;remember();revokeView();active=username;threadAllowed=false;input.disabled=true;listView.hidden=true;chatView.hidden=false;status.textContent='';input.value=drafts.get(username)||'';sendState();
  $('shMsgChatName').textContent=nameOf1873(chats.find(x=>x.username===username)||{username});host.replaceChildren(el('p','sh-msg-empty','Memuat pesan…'));const data=chats.find(x=>x.username===username);$('shMsgChatAvatar').replaceChildren(...avatar(username,data?.avatarUrl).childNodes);
  refreshThread(true);schedule();input.focus();
 }
 async function send(e){
  e.preventDefault();const name=active,original=input.value,body=original.trim(),stamp=view,session=authEpoch,draftVersion=draftVersions.get(active)||0;
  if(!body||!name||sending.has(name)||!open||!threadAllowed)return;
  if(!visible()){status.textContent='Offline · draf tetap tersimpan selama halaman ini terbuka.';return}
  drafts.set(name,original);sending.add(name);sendState();status.textContent='Mengirim…';
  try{
   await api('/messages','POST',{username:name,body});
   // Do not clear a new draft or reopen the previous recipient if navigation happened in-flight.
   if(session!==authEpoch)return;
   const unchanged=(draftVersions.get(name)||0)===draftVersion&&drafts.get(name)===original;
   if(unchanged)drafts.delete(name);
   if(open&&active===name){if(unchanged&&input.value===original)input.value='';status.textContent='Pesan terkirim.';await refreshThread(false)}
   window.dispatchEvent(new Event('mm:dm-updated'));
  }catch(err){
   if(valid(stamp,name)){status.textContent=err.code?err.message:'Pengiriman belum terkonfirmasi. Periksa percakapan sebelum mencoba lagi.'}
   // A timed-out POST is never retried automatically: the server may already have committed it.
  }finally{sending.delete(name);sendState()}
 }
 function schedule(){clearTimeout(timer);if(!visible())return;const delay=Math.min(60000,(open&&active?6000:30000)*Math.pow(2,Math.min(failures,3)));timer=setTimeout(async()=>{if(visible()){if(open&&active){await refreshThread();if(Date.now()-lastCountAt>=30000)await pollCount()}else{await pollCount();if(open)await loadList()}}schedule()},delay)}
 function full(e){if(active)window.dispatchEvent(new CustomEvent('mm:dm-open',{detail:{username:active}}));setOpen(false);const target=$('shMessagePanel');if(target){e.preventDefault();target.scrollIntoView({behavior:'smooth',block:'start'})}}
 button.addEventListener('click',()=>setOpen(!open));$('shMsgClose').addEventListener('click',()=>{setOpen(false);button.focus()});
 $('shMsgBack').addEventListener('click',()=>{remember();revokeView();active=null;input.value='';listView.hidden=false;chatView.hidden=true;status.textContent='';render();loadList();schedule()});
 $('shMsgSearch').addEventListener('input',render);for(const tab of pane.querySelectorAll('[data-msg-filter]'))tab.addEventListener('click',()=>setFilter(tab.dataset.msgFilter));
 input.addEventListener('input',()=>remember(true));$('shMsgCompose').addEventListener('submit',send);
 newMessages.addEventListener('click',()=>{host.scrollTop=host.scrollHeight;newMessages.hidden=true;acknowledge()});host.addEventListener('scroll',()=>{if(nearBottom()){newMessages.hidden=true;acknowledge()}},{passive:true});
 $('shMsgSeeAll').addEventListener('click',full);$('shMsgOpenFull').addEventListener('click',full);$('shMsgNewChat').addEventListener('click',e=>{setOpen(false);e.preventDefault();$('shFriendSearch').scrollIntoView({behavior:'smooth',block:'center'});$('shFriendQuery').focus()});
 document.addEventListener('pointerdown',e=>{if(open&&!wrap.contains(e.target)&&!e.target.closest?.('#mmEmojiPicker1877'))setOpen(false)});document.addEventListener('keydown',e=>{if(e.key==='Escape'&&open){setOpen(false);button.focus()}});
 window.addEventListener('mm:notification-open',()=>{if(open)setOpen(false)});window.addEventListener('mm:dm-updated',()=>{pollCount();if(open&&!active)loadList()});
 function resume(){if(visible()){pollCount();if(open){if(active)refreshThread();else loadList()}}schedule()}
 document.addEventListener('visibilitychange',()=>{if(document.hidden){clearTimeout(timer);for(const job of jobs)if(job.method==='GET')job.controller.abort()}else resume()});
 window.addEventListener('online',resume);window.addEventListener('offline',()=>{clearTimeout(timer);if(open)status.textContent='Offline · draf tetap ada selama halaman ini terbuka.'});
 window.addEventListener('pagehide',()=>{clearTimeout(timer);for(const job of jobs)job.controller.abort()});window.addEventListener('pageshow',resume);
 pollCount();schedule();
})();
