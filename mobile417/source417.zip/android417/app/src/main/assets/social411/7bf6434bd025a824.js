/* MarketMarney v18.5.2 — hide/show controls with local preference and deep-link support. */
(()=>{'use strict';
const panels=[
  {name:'friends',button:'shFriendToggle',body:'shFriendBody'},
  {name:'messages',button:'shMessageToggle',body:'shMessageBody'},
  {name:'groups',button:'shGroupToggle',body:'shGroupCollapseBody'}
].map(p=>({...p,buttonEl:document.getElementById(p.button),bodyEl:document.getElementById(p.body)}));
const storagePrefix='marketmarney:beranda-trader:sidebar:v1852:';
const mobilePrefix='marketmarney:beranda-trader:mobile-account:v1868:';
const inMobileMenu=p=>!!p.buttonEl?.closest('#shMobileAccountPanels');
const storageKey=p=>(inMobileMenu(p)?mobilePrefix:storagePrefix)+p.name;
function toggle(p,expanded,persist=true){if(!p.buttonEl||!p.bodyEl)return;
  p.bodyEl.hidden=!expanded;
  p.buttonEl.setAttribute('aria-expanded',String(expanded));
  const state=p.buttonEl.querySelector('.sh-collapse-state');if(state)state.textContent=expanded?'Sembunyikan':'Tampilkan';
  if(persist){try{localStorage.setItem(storageKey(p),expanded?'open':'closed')}catch{}}
}
for(const p of panels){if(!p.buttonEl||!p.bodyEl)continue;
  let saved=null;try{saved=localStorage.getItem(storageKey(p))}catch{}
  toggle(p,saved!=='closed',false);
  p.buttonEl.addEventListener('click',()=>toggle(p,p.bodyEl.hidden));
}
function revealTarget(hash){if(!hash||hash[0]!=='#')return;
  let target;try{target=document.getElementById(decodeURIComponent(hash.slice(1)))}catch{return}
  if(!target)return;
  for(const p of panels){if(p.bodyEl && (p.bodyEl.contains(target) || target===p.buttonEl.closest('.sh-collapsible-card'))){toggle(p,true);break}}
}
// Open a collapsed panel before existing scripts focus its input or scroll to its anchor.
document.addEventListener('click',event=>{
  const a=event.target.closest('a[href^="#"]');if(a)revealTarget(a.getAttribute('href'));
},true);
window.addEventListener('hashchange',()=>revealTarget(location.hash));
window.addEventListener('mm:dm-open',()=>toggle(panels[1],true));
window.addEventListener('mm:sidebar-layout',()=>{for(const p of panels){if(!p.buttonEl||!p.bodyEl)continue;let saved=null;try{saved=localStorage.getItem(storageKey(p))}catch{};toggle(p,saved==='open'||(saved!=='closed'&&!inMobileMenu(p)),false)}});
revealTarget(location.hash);
})();
