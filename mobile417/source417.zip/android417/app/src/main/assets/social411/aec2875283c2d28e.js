(()=>{'use strict';
const $=id=>document.getElementById(id),wrap=$('shNotificationWrap'),bell=$('shNotificationBell'),pane=$('shNotificationPane');
if(!wrap||!bell||!pane)return;
const list=$('shNotificationList'),status=$('shNotificationStatus'),badge=$('shNotificationCount'),readAll=$('shNoticeReadAll');
let logged=false,opening=false,loading=false;
const icons={follow:'＋',like:'♥',comment:'▤',reply:'↩',comment_like:'♥',dm:'✉'};
const api=async(path,method='GET',body)=>{
 const opts={method,credentials:'same-origin',cache:'no-store'};
 if(method!=='GET'){opts.headers={'Content-Type':'application/json','X-MarketMarney-Request':'1'};opts.body=JSON.stringify(body)}
 const r=await fetch('/api/trader-notifications'+path,opts),d=await r.json().catch(()=>({}));
 if(!r.ok)throw Object.assign(Error(d.error||'Gagal memuat notifikasi'),{code:r.status});return d;
};
function textEl(tag,cls,value){const node=document.createElement(tag);if(cls)node.className=cls;node.textContent=value;return node}
function count(n){const safe=Math.max(0,Number(n)||0);badge.hidden=safe===0;badge.textContent=safe>99?'99+':String(safe);bell.setAttribute('aria-label',safe?safe+' notifikasi trader belum dibaca':'Buka notifikasi trader')}
function show(open){opening=!!open;pane.hidden=!opening;bell.setAttribute('aria-expanded',String(opening));if(opening)load();}
function render(items){list.replaceChildren();if(!items.length){list.append(textEl('p','sh-notice-empty','Belum ada notifikasi. Aktivitas Follow, komentar, suka, dan pesan akan muncul di sini.'));return}
 for(const item of items){const a=document.createElement('a');a.className='sh-notice-item'+(item.read?'':' is-unread');a.href=item.url;
  const icon=textEl('span','sh-notice-icon',icons[item.type]||'•');icon.setAttribute('aria-hidden','true');
  const meta=textEl('span','sh-notice-detail',item.message),time=textEl('small','',new Date(item.createdAt).toLocaleString('id-ID',{dateStyle:'medium',timeStyle:'short'}));meta.append(time);
  a.append(icon,meta);if(!item.read)a.append(textEl('span','sh-notice-dot','●'));
  a.addEventListener('click',event=>{if(item.read)return;event.preventDefault();api('/read','POST',{id:item.id}).catch(()=>{}).finally(()=>{window.location.assign(item.url)})});list.append(a);
 }
}
async function loadCount(){try{const data=await api('/count');logged=true;wrap.hidden=false;count(data.unread)}catch(e){if(e.code===401){logged=false;wrap.hidden=true;show(false)}}}
async function load(){if(!logged||loading)return;loading=true;status.textContent='';try{const data=await api('');render(data.items);count(data.unread);readAll.disabled=!data.unread;status.textContent='Menampilkan hingga 40 aktivitas terbaru.'}catch(e){status.textContent=e.message;list.replaceChildren(textEl('p','sh-notice-empty','Notifikasi belum bisa dimuat. Coba buka kembali.'))}finally{loading=false}}
bell.addEventListener('click',()=>{const next=!opening;show(next);if(next)window.dispatchEvent(new Event('mm:notification-open'))});
window.addEventListener('mm:messenger-open',()=>show(false));
readAll.addEventListener('click',async()=>{readAll.disabled=true;try{await api('/read','POST',{all:true});await load()}catch(e){status.textContent=e.message}finally{if(!badge.hidden)readAll.disabled=false}});
document.addEventListener('pointerdown',e=>{if(opening&&!wrap.contains(e.target))show(false)});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&opening){show(false);bell.focus()}});
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible'){loadCount();if(opening)load()}});
loadCount();setInterval(()=>{if(document.visibilityState==='visible'){loadCount();if(opening)load()}},45000);
})();
