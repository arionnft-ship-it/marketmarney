(()=>{'use strict';
const make=(t,c,s)=>{const n=document.createElement(t);if(c)n.className=c;if(s!==undefined)n.textContent=s;return n;};
function urls(text){const result=[];for(const m of text.matchAll(/(?:https?:\/\/|www\.)[^\s<>"'`]+/gi)){let raw=m[0].replace(/[.,;:!?\])}]+$/g,'');try{const u=new URL(raw.startsWith('www.')?'https://'+raw:raw);if(!['http:','https:'].includes(u.protocol)||u.username||u.password||raw.length>2048)continue;result.push({index:m.index,text:raw,url:u.href,host:u.hostname});}catch{}}return result;}
function text(node,value){node.replaceChildren();let end=0;for(const u of urls(String(value))){node.append(document.createTextNode(value.slice(end,u.index)));const a=make('a','gm-web-link',u.text);a.href=u.url;a.target='_blank';a.rel='noopener noreferrer nofollow ugc';a.referrerPolicy='no-referrer';a.title='Tautan eksternal · '+u.host;node.append(a);end=u.index+u.text.length;}node.append(document.createTextNode(value.slice(end)));}
const bytes=n=>Number(n)>=1048576?(Number(n)/1048576).toFixed(1)+' MB':Math.max(1,Math.ceil(Number(n)/1024))+' KB';
function fileCard(f){if(!f||!/^\/api\/trader-connect\/group-media\/[a-f0-9-]{36}$/.test(f.url))return null;
 const a=make('a','gm-document-card');a.href=f.url;a.download=f.name;a.setAttribute('aria-label','Unduh '+f.name);a.title='Unduh berkas. Buka hanya dokumen yang Anda percayai.';
 const icon=make('span','gm-document-icon',String(f.extension||'FILE').toUpperCase());icon.setAttribute('aria-hidden','true');const body=make('span','gm-document-copy');body.append(make('strong','',f.name),make('small','',bytes(f.bytes)+' · Unduh berkas'));const arrow=make('span','gm-document-arrow','↓');arrow.setAttribute('aria-hidden','true');a.append(icon,body,arrow);return a;
}
window.GroupRich1874={text,urls,bytes,fileCard};
})();
