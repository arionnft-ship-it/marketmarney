/* Shared, small accessibility/comfort helpers. Does not send/store data or alter permissions. */
(()=>{'use strict';
 const visible=e=>!!e&&e.getClientRects().length&&!e.closest('[hidden],[inert]');
 function ready(){
  // Link to the visible workspace, including the signed-in account whose <main> is hidden.
  if(!document.querySelector('a.mm81-skip,a.skip-link,a.about-skip')){
   const skip=document.createElement('a');skip.className='mm81-skip';skip.href='#mm81-main';skip.textContent='Lewati ke konten utama';
   skip.addEventListener('click',e=>{e.preventDefault();const target=[document.getElementById('mm36Account'),...document.querySelectorAll('main'),document.getElementById('gmApp')].find(visible);if(!target)return;
    if(!target.hasAttribute('tabindex'))target.setAttribute('tabindex','-1');target.focus({preventScroll:true});target.scrollIntoView({block:'start',behavior:'instant'});
   });document.body.prepend(skip);
  }
  let n=0;
  document.querySelectorAll('input[type=password]').forEach(input=>{
   if(input.closest('.mm81-password'))return;
   if(!input.id)input.id='mm81-password-'+(++n);
   const wrapper=document.createElement('span');wrapper.className='mm81-password';input.before(wrapper);wrapper.append(input);
   const button=document.createElement('button');button.type='button';button.className='mm81-password-toggle';button.textContent='Lihat';button.setAttribute('aria-controls',input.id);button.setAttribute('aria-pressed','false');button.setAttribute('aria-label','Tampilkan password');
   function set(show){input.type=show?'text':'password';button.textContent=show?'Sembunyi':'Lihat';button.setAttribute('aria-pressed',String(show));button.setAttribute('aria-label',show?'Sembunyikan password':'Tampilkan password');}
   button.addEventListener('click',e=>{e.preventDefault();set(input.type==='password');});wrapper.append(button);
   document.addEventListener('visibilitychange',()=>{if(document.hidden)set(false);});
  });
  // Real same-page section links can reveal collapsed details, but never unhide login/private panels.
  document.addEventListener('click',e=>{
   const a=e.target.closest('a[href^="#"]');if(!a||e.button!==0||e.ctrlKey||e.metaKey||e.altKey||e.shiftKey)return;
   let id;try{id=decodeURIComponent(a.getAttribute('href').slice(1));}catch{return;}
   const target=document.getElementById(id);if(!target)return;
   for(let d=target.closest('details');d;d=d.parentElement?.closest('details'))d.open=true;
  });
  const reels=document.getElementById('shReelsPanel');if(reels?.tagName==='DETAILS')reels.addEventListener('toggle',()=>{if(!reels.open)reels.querySelectorAll('video').forEach(video=>video.pause());});
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',ready,{once:true});else ready();
})();
