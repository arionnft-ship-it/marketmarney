(()=>{'use strict';
// Shared, live profile card for timeline/comments and group authors. No private data cache.
const make=(tag,cls,text)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n;};
const valid=u=>typeof u==='string'&&/^[a-z][a-z0-9_]{2,23}$/i.test(u);
const avatarUrl=u=>typeof u==='string'&&/^\/media\/[a-f0-9-]{36}\.(png|jpg|webp)$/.test(u);
let dialog,content,status,closeButton,epoch=0,readController=null,active=null,opener=null;const writing=new Set();
function setup(){if(dialog)return;
 dialog=make('dialog','sm-profile-card');dialog.id='smProfileCard';dialog.setAttribute('aria-label','Profil Social Marney');
 const cover=make('div','sm-profile-cover'),brand=make('span','sm-profile-brand','SOCIAL MARNEY');
 const brandImage=make('img','mm417-brand-image');brandImage.src='/__android417/brand/logo.png';brandImage.alt='MARNEY';brandImage.width=30;brandImage.height=30;brandImage.decoding='async';brandImage.loading='eager';brand.prepend(brandImage);
 closeButton=make('button','sm-profile-close','×');closeButton.type='button';closeButton.setAttribute('aria-label','Tutup profil');closeButton.addEventListener('click',()=>dialog.close());cover.append(brand,closeButton);
 content=make('div','sm-profile-content');status=make('p','sm-profile-status');status.setAttribute('role','status');status.setAttribute('aria-live','polite');dialog.append(cover,content,status);document.body.append(dialog);
 dialog.addEventListener('close',()=>{if(dialog.open)return;epoch++;readController?.abort();active=null;content.replaceChildren();status.textContent='';if(opener?.isConnected)opener.focus({preventScroll:true});opener=null;});
 dialog.addEventListener('click',e=>{if(e.target===dialog){const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)dialog.close();}});
}
async function request(url,method='GET',body,signal){const options={method,credentials:'same-origin',cache:'no-store',signal};if(body){options.headers={'Content-Type':'application/json','X-MarketMarney-Request':'1'};options.body=JSON.stringify(body);}const r=await fetch(url,options),d=await r.json().catch(()=>({}));if(!r.ok)throw Object.assign(Error(d.error||'Profil belum dapat dimuat.'),{status:r.status});return d;}
function render(p){content.replaceChildren();
 const av=make('div','sm-profile-avatar',(p.displayName||p.username).slice(0,2).toUpperCase());if(avatarUrl(p.avatarUrl)){const img=make('img');img.src=p.avatarUrl;img.alt='';img.addEventListener('error',()=>{if(av.contains(img))av.textContent=(p.displayName||p.username).slice(0,2).toUpperCase();});av.replaceChildren(img);}
 const identity=make('div','sm-profile-identity');identity.append(make('h2','',p.displayName||p.username),make('p','sm-profile-handle','@'+p.username));content.append(av,identity);window.SocialIdentity1875?.badge(identity.querySelector('h2'),p);
 if(p.isSelf)identity.append(make('span','sm-profile-tag','Profil Anda'));else if(p.mutual)identity.append(make('span','sm-profile-tag','Saling mengikuti'));else if(p.followsYou)identity.append(make('span','sm-profile-tag','Mengikuti Anda'));
 const counts=make('div','sm-profile-counts');for(const [key,label] of [['followers','Pengikut'],['following','Mengikuti']]){const c=make('div');c.append(make('strong','',String(p[key]||0)),make('span','',label));counts.append(c);}content.append(counts);if(p.communityBadge?.eligible){content.append(make('p','sm-badge-explainer','Lencana komunitas · 1.000+ pengikut. Bukan verifikasi identitas.'));}
 if(p.groupOwnerBadge?.eligible)content.append(make('p','sm-badge-explainer sm-owner-explainer','Ceklis emas · Pemilik grup dengan 999+ anggota aktif. Bukan verifikasi identitas atau akun resmi MarketMarney.'));
 const bio=make('div','sm-profile-bio');bio.append(make('small','','BIO'),make('p','',p.bio||'Belum ada bio.'));content.append(bio);
 const actions=make('div','sm-profile-actions');
 if(p.isSelf){const edit=make('a','sm-profile-primary','Edit profil');edit.href='/akun.html?pengaturan=1';actions.append(edit);}
 else if(!p.loggedIn){const login=make('a','sm-profile-primary','Masuk untuk mengikuti');login.href='/akun.html';actions.append(login);}
 else{const follow=make('button','sm-profile-primary'+(p.isFollowing?' is-following':''),p.isFollowing?'Mengikuti · Unfollow':'+ Follow');follow.type='button';follow.disabled=writing.has(p.username);follow.setAttribute('aria-pressed',String(!!p.isFollowing));follow.setAttribute('aria-label',(p.isFollowing?'Unfollow ':'Follow ')+(p.displayName||p.username));follow.dataset.profileFollow=p.username;
 follow.addEventListener('click',()=>toggle(p));actions.append(follow);
 if(p.mutual){const chat=make('a','sm-profile-secondary','Kirim pesan');chat.href='/beranda-trader.html?chat='+encodeURIComponent(p.username);actions.append(chat);}}
 const full=make('a','sm-profile-full','Lihat profil lengkap ↗');full.href='/profil.html?user='+encodeURIComponent(p.username);content.append(actions,full);
 if(p.loggedIn&&!p.isSelf&&!p.mutual)content.append(make('p','sm-profile-hint','Pesan pribadi tersedia setelah saling mengikuti.'));
}
async function show(username,trigger){if(!valid(username))return;setup();epoch++;const token=epoch;readController?.abort();readController=new AbortController();const controller=readController;active=username;opener=trigger||document.activeElement;status.textContent='';content.replaceChildren(make('p','sm-profile-loading','Memuat profil…'));if(!dialog.open)dialog.showModal();closeButton.focus();
 const timer=setTimeout(()=>controller.abort(),12000);
 try{const p=await request('/api/trader-follow/status?user='+encodeURIComponent(username),'GET',null,controller.signal);if(token!==epoch||!dialog.open)return;active=p.username;render(p);}
 catch(e){if(token!==epoch||!dialog.open)return;content.replaceChildren(make('p','sm-profile-loading',e.status===404?'Profil tidak tersedia.':e.name==='AbortError'?'Koneksi terlalu lama. Coba lagi.':e.message));const retry=make('button','sm-profile-primary','Coba lagi');retry.type='button';retry.addEventListener('click',()=>show(username,opener));content.append(retry);}
 finally{clearTimeout(timer);}
}
async function toggle(p){if(writing.has(p.username))return;writing.add(p.username);const token=epoch,controller=new AbortController(),timer=setTimeout(()=>controller.abort(),12000);render(p);status.textContent='Menyimpan…';
 try{const r=await request('/api/trader-follow',p.isFollowing?'DELETE':'POST',{username:p.username},controller.signal);
  window.dispatchEvent(new CustomEvent('mm:follow-updated',{detail:{username:p.username,isFollowing:r.isFollowing}}));
  if(token===epoch&&dialog.open&&active===p.username){Object.assign(p,r);render(p);status.textContent=r.isFollowing?'Akun berhasil diikuti.':'Anda berhenti mengikuti akun ini.';}}
 catch(e){if(token===epoch&&dialog.open){if(e.status===401){p.loggedIn=false;render(p);}status.textContent=e.name==='AbortError'?'Hasil belum diketahui. Tutup dan buka profil untuk memeriksa sebelum mencoba lagi.':e.message;}}
 finally{clearTimeout(timer);writing.delete(p.username);if(dialog.open&&active===p.username){if(token!==epoch)void show(p.username,opener);else{const b=content.querySelector('[data-profile-follow]');if(b)b.disabled=false;}}}
}
function bind(node,user,options={}){const username=typeof user==='string'?user:user?.username;if(!valid(username)||!node)return node;node.dataset.socialProfile=username;node.classList.add('sm-profile-trigger');if(node.tagName==='BUTTON')node.type='button';else if(node.tagName!=='A'){node.tabIndex=0;node.setAttribute('role','button');}node.setAttribute('aria-haspopup','dialog');node.setAttribute('aria-label','Lihat profil '+(user?.displayName||username));node.title='Lihat profil';if(!/(?:avatar)/i.test(node.className))window.SocialIdentity1875?.badge(node,user,'username',options);return node;}
document.addEventListener('click',e=>{const node=e.target.closest?.('[data-social-profile]');if(!node||e.ctrlKey||e.metaKey||e.shiftKey||e.altKey)return;e.preventDefault();void show(node.dataset.socialProfile,node);});
document.addEventListener('keydown',e=>{const node=e.target.closest?.('[data-social-profile]');if(node&&!['A','BUTTON'].includes(node.tagName)&&['Enter',' '].includes(e.key)){e.preventDefault();void show(node.dataset.socialProfile,node);}});
window.SocialProfile1874={bind,open:show};
})();
