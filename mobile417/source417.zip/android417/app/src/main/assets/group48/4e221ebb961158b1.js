(()=>{'use strict';
const nameOf1873=(u,key='username')=>String(u?.[key==='username'?'displayName':key+'DisplayName']||u?.[key]||'Trader');

const $=id=>document.getElementById(id);
const make=(tag,cls,value)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(value!==undefined)n.textContent=value;return n};
const state={me:null,mine:[],discover:[],active:null,group:null,items:[],view:'mine',infoOpen:false,infoAutoOpened:false,
  selectSeq:0,listSeq:0,memberSeq:0,removedSeq:0,roster:[],memberNext:0,memberMore:false,removed:[],removedNext:0,removedMore:false,
  rosterKey:'',drafts:new Map(),mediaDrafts:new Map(),photoSeq:0,avatarSeq:0,avatarDraft:null,avatarBusy:false,pendingAction:null,actionBusy:false,sending:new Set(),editKey:'',privacyEditKey:'',privacyBusy:false,requestSeq:0,requests:[],requestNext:0,requestMore:false,requestBusy:false};
const say=t=>{const n=$('gmStatus');n.textContent=t;clearTimeout(say.timer);say.timer=setTimeout(()=>{n.textContent=''},6500)};
const fmt=ms=>new Date(ms).toLocaleTimeString('id-ID',{hour:'2-digit',minute:'2-digit'});
const api=async(route,method='GET',body)=>{
  const opts={method,credentials:'same-origin',cache:'no-store'};
  if(method!=='GET'){opts.headers={'Content-Type':'application/json','X-MarketMarney-Request':'1'};opts.body=JSON.stringify(body||{})}
  const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),15000);opts.signal=controller.signal;
  try{const res=await fetch('/api/trader-connect'+route,opts),data=await res.json().catch(()=>({}));
    if(res.status===401)invalidateSession();if(!res.ok)throw Object.assign(Error(data.error||'Permintaan gagal'),{status:res.status});return data;
  }catch(e){if(e.name==='AbortError')throw Error('Koneksi terlalu lama. Periksa hasil sebelum mencoba kembali.');throw e}finally{clearTimeout(timeout)}
};
function useTheme(){try{document.documentElement.dataset.traderTheme=localStorage.getItem('mm1839-last-theme')==='dark'?'dark':'light'}catch{}}
const groupPhotoUrl=url=>typeof url==='string'&&/^\/api\/trader-connect\/group-media\/[0-9a-f-]{36}$/.test(url);
function setGroupAvatar(node,name,url){
 const key=(url||'')+':'+name;if(node.dataset.photoKey===key)return;node.dataset.photoKey=key;node.textContent=String(name||'G').slice(0,1).toUpperCase();
 if(groupPhotoUrl(url)){const img=make('img');img.src=url;img.alt='';img.loading='lazy';img.addEventListener('error',()=>{if(node.contains(img))node.textContent=String(name||'G').slice(0,1).toUpperCase()});node.replaceChildren(img)}
}
function mediaDraft(id=state.active){if(!state.mediaDrafts.has(id))state.mediaDrafts.set(id,{reply:null,image:null,file:null,attempt:null,error:''});return state.mediaDrafts.get(id)}
function clearImage(id){const d=state.mediaDrafts.get(id);if(d?.image?.url)URL.revokeObjectURL(d.image.url);if(d){d.image=null;d.attempt=null}}
function clearFile(id){const d=state.mediaDrafts.get(id);if(d){d.file=null;d.attempt=null}}
function clearMediaDraft(id){clearImage(id);clearFile(id);state.mediaDrafts.delete(id)}
function renderComposer(){const d=mediaDraft();$('gmReplyContext').hidden=!d.reply;$('gmPhotoContext').hidden=!d.image;$('gmFileContext').hidden=!d.file;if(d.file){$('gmFileName').textContent=d.file.name;$('gmFileSize').textContent=window.GroupRich1874.bytes(d.file.blob.size)+' · Dokumen siap dikirim';$('gmFileType').textContent=d.file.extension.toUpperCase();}
 if(d.reply){$('gmReplyTitle').textContent='Membalas '+nameOf1873(d.reply);$('gmReplyText').textContent=d.reply.body||'📷 Foto'}
 if(d.image){if($('gmPhotoPreview').src!==d.image.url)$('gmPhotoPreview').src=d.image.url;$('gmPhotoCaption').textContent=Math.max(1,Math.round(d.image.blob.size/1024))+' KB · Tambahkan keterangan bila diperlukan.'}else $('gmPhotoPreview').removeAttribute('src');
 const busy=state.sending.has(state.active);$('gmSend').disabled=busy;$('gmAttach').disabled=busy;$('gmPhotoCancel').disabled=busy;$('gmFileCancel').disabled=busy;for(const b of $('gmAttachmentPicker').querySelectorAll('button'))b.disabled=busy;
 $('gmComposeStatus').textContent=busy?'Mengirim… Jangan menutup halaman.':d.error||'';
}
function startReply(m){if(!state.group?.joined)return;mediaDraft().reply={id:m.id,username:m.username,displayName:m.displayName,body:(m.body||(m.attachment?'📎 '+m.attachment.name:m.imageUrl?'📷 Foto':'Pesan')).slice(0,180)};mediaDraft().attempt=null;renderComposer();$('gmBody').focus()}
function jumpReply(id){const node=[...$('gmMessages').querySelectorAll('[data-message-id]')].find(n=>n.dataset.messageId===id);
 if(node){node.scrollIntoView({behavior:'smooth',block:'center'});node.classList.add('gm-message-highlight');setTimeout(()=>node.classList.remove('gm-message-highlight'),1800)}else say('Pesan asal tidak ada pada 120 pesan yang dimuat.');}
function openImage(url,caption){if(!groupPhotoUrl(url))return;$('gmImageFull').src=url;$('gmImageCaption').textContent=caption||'Foto grup';$('gmImageViewer').showModal();$('gmImageClose').focus()}
function closeImage(){if($('gmImageViewer').open)$('gmImageViewer').close();$('gmImageFull').removeAttribute('src')}
function renderList(){const host=$('gmList'),signature=JSON.stringify([state.active,state.view,state.mine,state.discover,$('gmQuery').value]);if(host.dataset.mm48Signature===signature)return;host.dataset.mm48Signature=signature;host.replaceChildren();const q=$('gmQuery').value.trim().toLocaleLowerCase('id'),src=state.view==='mine'?state.mine:state.discover;
  const visible=src.filter(g=>(g.name+' '+g.description).toLocaleLowerCase('id').includes(q));
  if(!visible.length){host.append(make('p','gm-muted',q?'Tidak ada grup yang cocok.':'Belum ada grup. Buat atau jelajahi grup lain.'));return}
  for(const g of visible){const btn=make('button','gm-list-item'+(state.active===g.id?' active':''));btn.type='button';
    const av=make('div','gm-list-avatar');setGroupAvatar(av,g.name,g.avatarUrl);btn.append(av);const copy=make('div','gm-list-copy');
    copy.append(make('strong','',g.name),make('span','',g.lastMessage||g.description||'Grup Trader'));btn.append(copy,make('small','',g.members+' anggota · '+(g.visibility==='private'?'Privat':'Publik')));
    btn.addEventListener('click',()=>selectGroup(g.id));host.append(btn)}
}
async function refreshList(){const token=++state.listSeq,r=await api('/groups');if(token!==state.listSeq)return;state.mine=r.mine||[];state.discover=r.discover||[];if(state.group&&state.active===state.group.id){const g=state.group;state.mine=g.joined?(state.mine.some(x=>x.id===g.id)?state.mine.map(x=>x.id===g.id?g:x):[g,...state.mine]):state.mine.filter(x=>x.id!==g.id);state.discover=state.discover.map(x=>x.id===g.id?g:x);}renderList()}
function invalidateSession(){state.mm48Opening=null;state.photoSeq++;state.avatarSeq++;state.selectSeq++;for(const id of state.mediaDrafts.keys())clearMediaDraft(id);state.drafts.clear();state.me=null;state.mine=[];state.discover=[];clearAccess();state.active=null;state.group=null;$('gmApp').hidden=true;$('gmGuest').hidden=false;}
function clearAccess(){closeImage();if(!state.avatarBusy)closeAvatar();state.items=[];state.roster=[];state.removed=[];state.rosterKey='';state.memberSeq++;state.removedSeq++;
  $('gmPrivacyPanel').hidden=true;$('gmRequestsArea').hidden=true;state.requestSeq++;state.requests=[];$('gmRequestList').replaceChildren();
  $('gmCompose').hidden=true;$('gmPinned').hidden=true;$('gmMessages').replaceChildren();$('gmMemberList').replaceChildren();$('gmRemovedList').replaceChildren();
  $('gmMemberMore').hidden=true;$('gmRemovedMore').hidden=true;$('gmOwnerControls').hidden=true;$('gmRemovedArea').hidden=true;
  if($('gmMemberDialog').open&&!state.actionBusy)$('gmMemberDialog').close();
}
function renderMessages(){const host=$('gmMessages'),atBottom=host.scrollTop+host.clientHeight>=host.scrollHeight-100,oldTop=host.scrollTop;
  const signature=JSON.stringify([state.active,state.group?.role,state.items,$('gmMessageQuery').value]);
  if(host.dataset.signature===signature)return;host.dataset.signature=signature;const prior=new Map(Array.from(host.children).filter(n=>n.dataset.messageId).map(n=>[n.dataset.messageId,n]));const fragment=document.createDocumentFragment();
  const term=$('gmMessageQuery').value.trim().toLocaleLowerCase('id');
  if(!state.group?.joined){host.replaceChildren();host.append(make('p','gm-muted',state.group?.removed?'Akses grup telah dicabut oleh pengelola.':'Gabung grup untuk melihat percakapan.'));return}
  const visible=state.items.filter(m=>!term||(m.body+' '+m.username+' '+nameOf1873(m)+' '+(m.attachment?.name||'')).toLocaleLowerCase('id').includes(term));
  if(!visible.length){host.replaceChildren();host.append(make('p','gm-muted',term?'Tidak ada pesan yang cocok pada 120 pesan terbaru.':'Belum ada pesan. Mulai diskusi pertama.'));return}
  const groupId=state.active;
  for(const m of visible){const key=JSON.stringify([state.active,state.group?.role,!!state.group?.canModerate,m]);const old=prior.get(m.id);
    if(old&&old.dataset.mm48Key===key){fragment.append(old);continue;}
    const msg=make('article','gm-msg'+(m.mine?' mine':''));msg.dataset.messageId=m.id;msg.dataset.mm48Key=key;
    const av=make('button','gm-msg-avatar',nameOf1873(m).slice(0,2).toUpperCase());av.type='button';if(m.avatarUrl&&/^\/media\/[a-f0-9-]{36}\.(jpg|png|webp)$/.test(m.avatarUrl)){const img=make('img');img.src=m.avatarUrl;img.alt='';img.loading='lazy';img.addEventListener('error',()=>{if(av.contains(img))av.textContent=nameOf1873(m).slice(0,2).toUpperCase()});av.replaceChildren(img)}window.SocialProfile1874?.bind(av,m);msg.append(av);const bubble=make('div','gm-bubble');
    const author=make('button','sm-author-button',m.mine?'Anda':nameOf1873(m));window.SocialProfile1874?.bind(author,m,{groupContext:true});const byline=make('div','gm-author-line1877');byline.append(author);if(m.groupRole==='owner'||m.groupRole==='admin'){const role=make('span','gm-role1877'+(m.groupRole==='owner'?' is-owner':''),m.groupRole==='owner'?'Pemilik':'Admin');role.title=m.groupRole==='owner'?'Pemilik grup ini':'Admin grup ini';byline.append(role)}bubble.append(byline);
    if(m.replyTo){const quote=make('button','gm-reply-quote');quote.type='button';quote.disabled=!!m.replyTo.deleted;
      quote.append(make('strong','',m.replyTo.deleted?'Pesan sudah dihapus':'↩ '+nameOf1873(m.replyTo)));if(!m.replyTo.deleted){quote.append(make('span','',m.replyTo.body||(m.replyTo.hasFile?'📎 '+m.replyTo.fileName:m.replyTo.hasImage?'📷 Foto':'Pesan')));quote.addEventListener('click',()=>jumpReply(m.replyTo.id))}bubble.append(quote)}
    if(m.imageUrl&&groupPhotoUrl(m.imageUrl)){const imageButton=make('button','gm-message-photo');imageButton.type='button';imageButton.setAttribute('aria-label','Buka foto dari '+nameOf1873(m));const image=make('img');image.src=m.imageUrl;image.alt='Foto dibagikan '+nameOf1873(m);image.loading='lazy';image.decoding='async';image.addEventListener('error',()=>{imageButton.replaceChildren(make('span','','Foto tidak tersedia.'));imageButton.disabled=true});imageButton.append(image);imageButton.addEventListener('click',()=>openImage(m.imageUrl,m.body));bubble.append(imageButton)}
    if(m.attachment){const card=window.GroupRich1874.fileCard(m.attachment);if(card)bubble.append(card)}if(m.body){const para=make('p');window.GroupRich1874.text(para,m.body);bubble.append(para)}const foot=make('div','gm-msg-foot');foot.append(make('time','',fmt(m.createdAt)));const reply=make('button','','Balas');reply.type='button';reply.setAttribute('aria-label','Balas pesan '+nameOf1873(m));reply.addEventListener('click',()=>startReply(m));foot.append(reply);
    if(state.group.canModerate){const pin=make('button','','Sematkan');pin.type='button';pin.addEventListener('click',()=>groupAction('/groups/pin',{groupId,messageId:m.id}));foot.append(pin)}
    if(m.canHide){const del=make('button','','Hapus');del.type='button';del.addEventListener('click',()=>{if(confirm('Hapus pesan ini dari grup?'))void groupAction('/groups/message-hide',{groupId,messageId:m.id})});foot.append(del)}
    bubble.append(foot);const reactions=make('div');bubble.append(reactions);window.SocialReactions1877?.mount(reactions,{kind:'group',id:m.id,groupId,initial:m.reactions,onChange:data=>{m.reactions=data;}});msg.append(bubble);fragment.append(msg)}
  host.replaceChildren(fragment);
  host.scrollTop=atBottom||!host.dataset.loaded?host.scrollHeight:oldTop;host.dataset.loaded='1';
}
function showGroup(){const g=state.group;if(!g)return;
  $('gmRoom').hidden=false;$('gmEmpty').hidden=true;$('gmApp').classList.add('room-open');$('gmRoomName').textContent=g.name;
  const role=g.role==='owner'?' · Pemilik':g.role==='admin'?' · Admin':'';
  $('gmRoomCount').textContent=(g.members===null?'Keanggotaan terbatas':g.members+' anggota')+role+' · '+(g.visibility==='private'?'Privat':'Publik');setGroupAvatar($('gmRoomAvatar'),g.name,g.avatarUrl);
  $('gmJoinArea').hidden=!!g.joined;$('gmCompose').hidden=!g.joined;
  $('gmJoin').hidden=!!g.removed;$('gmJoin').disabled=!!g.joinRequested;$('gmJoin').textContent=g.joinRequested?'Menunggu persetujuan':g.visibility==='private'?'Minta bergabung':'Gabung grup';$('gmJoinArea').querySelector('span').textContent=g.removed?'Anda dikeluarkan dari grup. Hubungi pemilik untuk meminta izin bergabung kembali.':g.joinRequested?'Permintaan terkirim. Percakapan terbuka setelah disetujui pemilik.':g.visibility==='private'?'Grup privat. Kirim permintaan bergabung kepada pemilik.':'Gabung untuk membaca dan mengirim pesan di grup ini.';
  $('gmPinned').hidden=!g.pinned;if(g.pinned)$('gmPinText').textContent=nameOf1873(g.pinned)+': '+g.pinned.body;
  $('gmUnpin').hidden=!g.canModerate;renderMessages();renderList();renderComposer();
  if(state.infoOpen)renderGroupInfo();else if(!state.infoAutoOpened&&innerWidth>=1150){state.infoAutoOpened=true;openGroupInfo()}
}
async function selectGroup(id,quiet=false){
  if(!id||state.mm48Opening===id)return;state.mm48Opening=id;const token=++state.selectSeq,changed=state.active!==id;
  if(changed){closePicker();state.photoSeq++;state.avatarSeq++;if(state.active){state.drafts.set(state.active,$('gmBody').value);mediaDraft().error='';if(!state.sending.has(state.active))$('gmComposeStatus').textContent=''};clearAccess();state.active=id;state.group=null;state.editKey='';
    $('gmRoom').hidden=true;$('gmEmpty').hidden=false;$('gmMemberSearch').value='';$('gmMessageQuery').value='';$('gmMessages').dataset.loaded='';$('gmMessages').dataset.signature='';
    $('gmBody').value=state.drafts.get(id)||'';$('gmSend').disabled=state.sending.has(id)}
  try{
    let group,items=[];
    try {
      const d=await api('/group-messages?id='+encodeURIComponent(id));
      if(token!==state.selectSeq||state.active!==id)return;
      group=d.group;items=d.items||[];
      if(!group||group.id!==id||!group.joined)throw Object.assign(Error('Akses grup tidak dapat diverifikasi.'),{status:403});
    }catch(e){
      if(e.status!==403)throw e;
      clearAccess();
      const fresh=await api('/groups/detail?id='+encodeURIComponent(id));
      if(token!==state.selectSeq||state.active!==id)return;
      group=fresh.group;
      // Detail alone cannot authorize access after messages were denied.
      if(group?.joined)throw Object.assign(Error('Izin grup berubah. Buka ulang grup untuk memeriksa akses.'),{status:403});
    }
    if(token!==state.selectSeq||state.active!==id)return;
    const previousRole=state.group?.role;if(!group.joined){clearAccess();state.drafts.delete(id);clearMediaDraft(id);$('gmBody').value=''}
    state.group=group;state.items=items;
    // Keep the sidebar count/preview aligned with the authoritative active room.
    state.discover=state.discover.map(g=>g.id===id?group:g);
    state.mine=group.joined?(state.mine.some(g=>g.id===id)?state.mine.map(g=>g.id===id?group:g):[group,...state.mine]):state.mine.filter(g=>g.id!==id);
    if(previousRole&&previousRole!==group.role){state.rosterKey='';if($('gmMemberDialog').open&&!state.actionBusy)$('gmMemberDialog').close()}
    showGroup();if(!quiet)history.replaceState(null,'','?group='+encodeURIComponent(id));
  }catch(e){if(token!==state.selectSeq||state.active!==id)return;
    if([401,403,404].includes(e.status)){clearAccess();state.group=null;$('gmRoom').hidden=true;$('gmEmpty').hidden=false;closeGroupInfo()}
    say(e.message)}finally{if(token===state.selectSeq)state.mm48Opening=null;}
}
async function groupAction(route,data){try{await api(route,'POST',data);await refreshList();if(state.active===data.groupId)await selectGroup(data.groupId,true);return true}catch(e){say(e.message);return false}}
function renderRoster(){const host=$('gmMemberList'),signature=JSON.stringify([state.active,state.group?.role,state.roster]);
  if(host.dataset.signature!==signature){host.dataset.signature=signature;host.replaceChildren();
    if(!state.roster.length)host.append(make('p','gm-muted','Tidak ada anggota yang cocok.'));
    for(const m of state.roster){const line=make('div','gm-member');line.dataset.username=m.username;
      const av=make('button','gm-member-avatar',nameOf1873(m).slice(0,2).toUpperCase());window.SocialProfile1874?.bind(av,m);if(m.avatarUrl&&/^\/media\/[0-9a-f-]{36}\.(?:jpg|png|webp)$/.test(m.avatarUrl)){const img=make('img');img.src=m.avatarUrl;img.alt='';av.replaceChildren(img)}
      const body=make('div','gm-member-detail');body.append(make('strong','', nameOf1873(m)+(m.isSelf?' · Anda':'')),make('small','sh-identity-handle','@'+m.username),make('small','gm-member-role is-'+m.role,m.role==='owner'?'Pemilik':m.role==='admin'?'Admin':'Anggota'));window.SocialIdentity1875?.badge(body.querySelector('strong'),m,'username',{groupContext:true});
      line.append(av,body);const actions=make('div','gm-member-actions');
      const add=(action,label,cls='')=>{const b=make('button',cls,label);b.type='button';b.dataset.memberAction=action;b.setAttribute('aria-label',label+' '+nameOf1873(m));b.addEventListener('click',()=>openMemberAction(action,m.username));actions.append(b)};
      if(m.canPromote)add('promote','Jadikan admin');if(m.canDemote)add('demote','Cabut admin');if(m.canKick)add('kick','Keluarkan','is-danger');
      if(actions.children.length)line.append(actions);host.append(line)}
  }
  $('gmMemberMore').hidden=!state.memberMore;
}
async function loadMembers(append=false){const groupId=state.active,role=state.group?.role;if(!state.group?.joined)return;
  const q=$('gmMemberSearch').value.trim(),offset=append?state.memberNext:0,token=++state.memberSeq;
  $('gmRosterStatus').textContent='Memuat anggota…';$('gmMemberMore').disabled=true;
  try{const d=await api('/groups/members?id='+encodeURIComponent(groupId)+'&q='+encodeURIComponent(q)+'&offset='+offset);
    if(token!==state.memberSeq||state.active!==groupId||!state.group?.joined||role!==state.group?.role||q!==$('gmMemberSearch').value.trim())return;
    state.roster=append?[...state.roster,...d.items.filter(m=>!state.roster.some(x=>x.username===m.username))]:d.items;state.memberNext=d.nextOffset;state.memberMore=d.hasMore;
    state.rosterKey=groupId+':'+state.group.role+':'+state.group.members;
    $('gmRosterStatus').textContent=state.roster.length+' dari '+d.filtered+' anggota';$('gmInfoMemberCount').textContent=String(d.total);renderRoster();
  }catch(e){if(token===state.memberSeq&&state.active===groupId){$('gmRosterStatus').textContent=e.message;if(e.status===403){state.roster=[];state.memberMore=false;renderRoster();void selectGroup(groupId,true)}}}
  finally{if(token===state.memberSeq)$('gmMemberMore').disabled=false}
}
async function loadRemoved(append=false){const id=state.active;if(state.group?.role!=='owner')return;const token=++state.removedSeq,offset=append?state.removedNext:0;
  $('gmRemovedStatus').textContent='Memuat…';$('gmRemovedMore').disabled=true;
  try{const d=await api('/groups/removed?id='+encodeURIComponent(id)+'&offset='+offset);if(token!==state.removedSeq||id!==state.active||state.group?.role!=='owner')return;
    state.removed=append?[...state.removed,...d.items.filter(m=>!state.removed.some(x=>x.username===m.username))]:d.items;state.removedNext=d.nextOffset;state.removedMore=d.hasMore;
    $('gmRemovedCount').textContent='('+d.total+')';$('gmRemovedList').replaceChildren();
    for(const m of state.removed){const line=make('div','gm-member'),av=make('div','gm-member-avatar',nameOf1873(m).slice(0,2).toUpperCase()),body=make('div','gm-member-detail');
      body.append(make('strong','',nameOf1873(m)),make('small','gm-member-role','Dikeluarkan'));const tools=make('div','gm-member-actions'),b=make('button','','Izinkan bergabung');b.type='button';b.addEventListener('click',()=>openMemberAction('restore',m.username));tools.append(b);line.append(av,body,tools);$('gmRemovedList').append(line)}
    $('gmRemovedStatus').textContent=d.total?'Izin bergabung tidak memasukkan pengguna secara otomatis.':'Belum ada anggota yang dikeluarkan.';$('gmRemovedMore').hidden=!d.hasMore;
  }catch(e){if(token===state.removedSeq&&id===state.active)$('gmRemovedStatus').textContent=e.message}
  finally{if(token===state.removedSeq)$('gmRemovedMore').disabled=false}
}
function renderGroupInfo(){const g=state.group;if(!g)return;
  $('gmInfoName').textContent=g.name;$('gmInfoCount').textContent=(g.members===null?'Keanggotaan terbatas':g.members+' anggota')+' · '+(g.visibility==='private'?'Privat':'Publik');setGroupAvatar($('gmInfoAvatar'),g.name,g.avatarUrl);$('gmAvatarControls').hidden=!g.canEditPhoto;$('gmAvatarRemove').hidden=!g.avatarUrl;$('gmInfoDesc').textContent=g.description||'Belum ada deskripsi grup';$('gmInfoOwner').textContent=g.owner?nameOf1873(g,'owner'):'Hanya terlihat oleh anggota';window.SocialIdentity1875?.badge($('gmInfoOwner'),g,'owner',{groupContext:true});
  $('gmMemberHint').textContent=g.role==='owner'?'Kelola admin dan anggota grup Anda.':g.role==='admin'?'Admin dapat mengeluarkan anggota biasa dan memoderasi pesan.':'Daftar anggota komunitas ini.';
  const key=g.id+':'+g.role+':'+g.members;if(g.joined&&key!==state.rosterKey)void loadMembers();
  if(!g.joined){$('gmMemberList').replaceChildren(make('p','gm-muted',g.removed?'Akses anggota tidak tersedia.':'Gabung grup untuk melihat daftar anggota.'));$('gmRosterStatus').textContent=''}
  $('gmMemberSearch').disabled=!g.joined;$('gmRosterRefresh').hidden=!g.joined;$('gmRemovedArea').hidden=g.role!=='owner';
  const links=new Set();for(const item of state.items)for(const link of window.GroupRich1874.urls(item.body))links.add(link.url);
  $('gmLinkList').replaceChildren();if(!links.size)$('gmLinkList').append(make('p','gm-muted','Belum ada tautan pada pesan terbaru.'));
  for(const url of [...links].slice(0,30)){const a=make('a','gm-link-item',url);a.href=url;a.target='_blank';a.rel='noopener noreferrer nofollow';$('gmLinkList').append(a)}
  $('gmFileList').replaceChildren();for(const item of state.items){const card=window.GroupRich1874.fileCard(item.attachment);if(card)$('gmFileList').append(card)}if(!$('gmFileList').children.length)$('gmFileList').append(make('p','gm-muted','Belum ada dokumen pada 120 pesan yang dimuat.'));
  renderPrivacy1884();
  $('gmOwnerControls').hidden=g.role!=='owner';$('gmLeave').hidden=!g.joined||g.role==='owner';
  if(state.editKey!==g.id){$('gmEditName').value=g.name;$('gmEditDesc').value=g.description||'';state.editKey=g.id}
}
function openGroupInfo(){if(!state.group)return;state.infoOpen=true;$('gmInfoPanel').hidden=false;$('gmApp').classList.add('info-open');renderGroupInfo()}
function closeGroupInfo(){state.infoOpen=false;$('gmInfoPanel').hidden=true;$('gmApp').classList.remove('info-open')}
const actionCopy={
  promote:['Jadikan admin','Izinkan @% mengelola anggota biasa, mengganti foto grup, menyematkan dan menghapus pesan grup.','Jadikan admin'],
  demote:['Cabut akses admin','@% akan kembali menjadi anggota biasa. Riwayat pesan tetap tersimpan.','Cabut admin'],
  kick:['Keluarkan anggota','@% tidak dapat membaca atau mengirim pesan grup, dan tidak dapat bergabung kembali sampai pemilik memberi izin. Riwayat pesan lama tidak dihapus.','Keluarkan'],
  restore:['Izinkan bergabung kembali','@% dapat bergabung kembali sebagai anggota biasa. Tindakan ini tidak langsung memasukkannya ke grup.','Izinkan bergabung']
};
function openMemberAction(action,username){if(state.actionBusy||!state.group?.joined)return;const copy=actionCopy[action];if(!copy)return;
  state.pendingAction={action,username,groupId:state.active};$('gmMemberDialogTitle').textContent=copy[0];$('gmMemberDialogText').textContent=copy[1].replace('%',username);$('gmMemberConfirm').textContent=copy[2];$('gmMemberActionError').textContent='';$('gmMemberDialog').showModal();$('gmMemberCancel').focus()}
function cancelAction(){if(!state.actionBusy){$('gmMemberDialog').close();state.pendingAction=null}}
$('gmMemberCancel').addEventListener('click',cancelAction);$('gmMemberCancelX').addEventListener('click',cancelAction);
$('gmMemberDialog').addEventListener('cancel',e=>{if(state.actionBusy)e.preventDefault();else state.pendingAction=null});
$('gmMemberActionForm').addEventListener('submit',async e=>{e.preventDefault();const a=state.pendingAction;if(!a||state.actionBusy)return;if(a.groupId!==state.active){cancelAction();return}
  state.actionBusy=true;for(const b of $('gmMemberActionForm').querySelectorAll('button'))b.disabled=true;$('gmMemberActionError').textContent='';
  const route=['promote','demote'].includes(a.action)?'role':a.action==='restore'?'restore':'kick';const payload={groupId:a.groupId,username:a.username};if(route==='role')payload.role=a.action==='promote'?'admin':'member';
  try{await api('/groups/members/'+route,'POST',payload);$('gmMemberDialog').close();state.pendingAction=null;state.rosterKey='';say('Pengaturan anggota diperbarui.');
    await refreshList();if(state.active===a.groupId){await selectGroup(a.groupId,true);await loadMembers();if(state.group?.role==='owner'&&$('gmRemovedArea').open)await loadRemoved()}
  }catch(err){$('gmMemberActionError').textContent=err.message}
  finally{state.actionBusy=false;for(const b of $('gmMemberActionForm').querySelectorAll('button'))b.disabled=false}
});
$('gmMemberSearch').addEventListener('input',()=>{state.memberSeq++;clearTimeout(state.searchTimer);state.searchTimer=setTimeout(()=>loadMembers(),200)});
$('gmRosterRefresh').addEventListener('click',()=>loadMembers());$('gmMemberMore').addEventListener('click',()=>loadMembers(true));
$('gmRemovedArea').addEventListener('toggle',()=>{if($('gmRemovedArea').open)void loadRemoved()});$('gmRemovedMore').addEventListener('click',()=>loadRemoved(true));
$('gmQuery').addEventListener('input',renderList);
for(const [id,view] of [['gmFilterMine','mine'],['gmFilterDiscover','discover']])$(id).addEventListener('click',()=>{state.view=view;$('gmFilterMine').classList.toggle('active',view==='mine');$('gmFilterDiscover').classList.toggle('active',view==='discover');renderList()});

function renderPrivacy1884(){const g=state.group,owner=g?.joined&&g.role==='owner';$('gmPrivacyPanel').hidden=!owner;$('gmRequestsArea').hidden=!owner||g.visibility!=='private';if(!owner)return;
 const key=g.id+':'+g.privacyRevision;if(state.privacyEditKey!==key){state.privacyEditKey=key;for(const n of $('gmPrivacyForm').querySelectorAll('[name=gmPrivacy]'))n.checked=n.value===g.visibility;$('gmPrivacyStatus').textContent='';}
 $('gmRequestCount').textContent=String(g.pendingRequests||0);
 const signature=g.id+':'+(g.pendingRequests||0);if($('gmRequestsArea').open&&$('gmRequestsArea').dataset.key!==signature&&!state.requestBusy){$('gmRequestsArea').dataset.key=signature;void loadRequests1884();}
}
async function loadRequests1884(append=false){const id=state.active;if(state.group?.role!=='owner'||state.group.visibility!=='private')return;const seq=++state.requestSeq,offset=append?state.requestNext:0;$('gmRequestStatus').textContent='Memuat permintaan…';$('gmRequestMore').disabled=true;
 try{const d=await api('/groups/requests?id='+encodeURIComponent(id)+'&offset='+offset);if(seq!==state.requestSeq||id!==state.active||state.group?.role!=='owner'||state.group.visibility!=='private')return;
 state.requests=append?[...state.requests,...d.items.filter(x=>!state.requests.some(a=>a.username===x.username))]:d.items;state.requestNext=d.nextOffset;state.requestMore=d.hasMore;$('gmRequestCount').textContent=String(d.total);$('gmRequestList').replaceChildren();
 for(const item of state.requests){const row=make('div','gm-request-row'),who=make('div','gm-request-who');who.append(make('strong','',nameOf1873(item)),make('small','','@'+item.username));const actions=make('div','gm-request-actions');for(const [decision,label] of [['approve','Setujui'],['reject','Tolak']]){const button=make('button','',label);button.type='button';button.setAttribute('aria-label',label+' '+nameOf1873(item));button.addEventListener('click',()=>decideRequest1884(id,item.username,decision));actions.append(button)}row.append(who,actions);$('gmRequestList').append(row)}
 $('gmRequestStatus').textContent=d.total?state.requests.length+' dari '+d.total+' permintaan':'Belum ada permintaan. Bagikan tautan grup kepada calon anggota.';$('gmRequestMore').hidden=!d.hasMore;
 }catch(e){if(seq===state.requestSeq&&id===state.active)$('gmRequestStatus').textContent=e.message}finally{if(seq===state.requestSeq)$('gmRequestMore').disabled=false}
}
async function decideRequest1884(id,username,decision){if(state.requestBusy||id!==state.active)return;state.requestBusy=true;for(const b of $('gmRequestsArea').querySelectorAll('button'))b.disabled=true;
 try{await api('/groups/requests/decide','POST',{groupId:id,username,decision});if(id===state.active){state.rosterKey='';await selectGroup(id,true);await loadRequests1884();say(decision==='approve'?'Anggota baru disetujui.':'Permintaan ditolak.')}}catch(e){if(id===state.active)$('gmRequestStatus').textContent=e.message}finally{state.requestBusy=false;for(const b of $('gmRequestsArea').querySelectorAll('button'))b.disabled=false}
}
$('gmRequestsArea').addEventListener('toggle',()=>{if($('gmRequestsArea').open)void loadRequests1884()});$('gmRequestRefresh').addEventListener('click',()=>loadRequests1884());$('gmRequestMore').addEventListener('click',()=>loadRequests1884(true));
$('gmPrivacyForm').addEventListener('submit',async e=>{e.preventDefault();const g=state.group;if(!g||g.role!=='owner'||state.privacyBusy)return;const chosen=$('gmPrivacyForm').querySelector('[name=gmPrivacy]:checked');if(!chosen)return;const visibility=chosen.value,id=g.id,revision=g.privacyRevision;
 if(visibility===g.visibility){$('gmPrivacyStatus').textContent='Privasi sudah sesuai.';return;}if(!confirm(visibility==='public'?'Jadikan grup publik? Nama, foto dan deskripsi akan terlihat di Jelajahi. Pengguna bisa langsung bergabung. Pesan tetap khusus anggota.':'Jadikan grup privat? Grup disembunyikan dari pencarian. Anggota lama tetap dapat mengakses; anggota baru memerlukan persetujuan Anda.'))return;
 state.privacyBusy=true;for(const n of $('gmPrivacyForm').querySelectorAll('input,button'))n.disabled=true;$('gmPrivacyStatus').textContent='Menyimpan…';
 try{await api('/groups/privacy','POST',{groupId:id,visibility,revision});await refreshList();if(id===state.active){state.privacyEditKey='';await selectGroup(id,true);$('gmPrivacyStatus').textContent='Privasi grup berhasil disimpan.';}}
 catch(err){if(id===state.active){if(err.status===409){state.privacyEditKey='';await selectGroup(id,true);}$('gmPrivacyStatus').textContent=err.message;}}
 finally{state.privacyBusy=false;for(const n of $('gmPrivacyForm').querySelectorAll('input,button'))n.disabled=false;}
});

$('gmCreate').addEventListener('click',()=>$('gmCreateDialog').showModal());for(const b of document.querySelectorAll('[data-close]'))b.addEventListener('click',()=>$(b.dataset.close).close());
$('gmCreateForm').addEventListener('submit',async e=>{e.preventDefault();const btn=$('gmCreateForm').querySelector('button[type=submit]');btn.disabled=true;
  try{const r=await api('/groups','POST',{name:$('gmCreateName').value.trim(),description:$('gmCreateDesc').value.trim(),visibility:$('gmCreateForm').querySelector('[name=gmCreateVisibility]:checked').value});$('gmCreateDialog').close();$('gmCreateForm').reset();await refreshList();await selectGroup(r.id);say('Grup trader berhasil dibuat.')}
  catch(err){say(err.message)}finally{btn.disabled=false}});
$('gmBack').addEventListener('click',()=>{$('gmApp').classList.remove('room-open');closeGroupInfo()});
$('gmJoin').addEventListener('click',async()=>{const id=state.active;if(!id)return;$('gmJoin').disabled=true;try{const result=await api('/groups/join','POST',{groupId:id});await refreshList();if(id===state.active)await selectGroup(id);say(result.requested?'Permintaan dikirim. Menunggu persetujuan pemilik.':'Anda sudah bergabung ke grup.')}
  catch(e){say(e.message)}finally{$('gmJoin').disabled=!!state.group?.joinRequested}});
$('gmCompose').addEventListener('submit',async e=>{e.preventDefault();const id=state.active,body=$('gmBody').value.trim(),d=mediaDraft(id),image=d.image,file=d.file,reply=d.reply;
 if(!id||(!body&&!image&&!file)||state.sending.has(id)||!state.group?.joined)return;
 d.error='';state.sending.add(id);const snapshot=$('gmBody').value;renderComposer();
 try{
  if(image&&!image.mediaId){const up=await uploadPhoto(id,'message',image.blob);image.mediaId=up.mediaId;}
  if(file&&!file.mediaId)file.mediaId=(await uploadPhoto(id,'message',file.blob,file.name,file.mime)).mediaId;
  const payload={groupId:id,body,imageId:image?.mediaId||null,fileId:file?.mediaId||null,replyToId:reply?.id||null};const fingerprint=JSON.stringify(payload);
  if(!d.attempt||d.attempt.fingerprint!==fingerprint)d.attempt={fingerprint,clientId:newClientId()};payload.clientId=d.attempt.clientId;
  await api('/group-messages','POST',payload);
  if(state.active===id&&$('gmBody').value===snapshot){$('gmBody').value='';state.drafts.delete(id)}else if(state.drafts.get(id)===snapshot)state.drafts.delete(id);
  if(d.image===image)clearImage(id);if(d.file===file)clearFile(id);if(d.reply===reply)d.reply=null;d.attempt=null;
  if(state.active===id){await selectGroup(id,true);$('gmMessages').scrollTop=$('gmMessages').scrollHeight}
 }catch(err){d.error=err.message;say(err.message);if(state.active===id)$('gmComposeStatus').textContent=err.message;}
 finally{state.sending.delete(id);if(state.active===id){renderComposer();$('gmBody').focus()}}
});
$('gmBody').addEventListener('input',()=>{if(state.active){state.drafts.set(state.active,$('gmBody').value);mediaDraft().error='';if(!state.sending.has(state.active))$('gmComposeStatus').textContent=''}});
$('gmBody').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing){e.preventDefault();$('gmCompose').requestSubmit()}});
$('gmInfo').addEventListener('click',openGroupInfo);$('gmRoomName').addEventListener('click',openGroupInfo);$('gmRoomName').style.cursor='pointer';$('gmInfoClose').addEventListener('click',closeGroupInfo);
$('gmCopyLink').addEventListener('click',async()=>{if(!state.active)return;const link=location.origin+'/grup-trader.html?group='+encodeURIComponent(state.active);try{await navigator.clipboard.writeText(link);say('Tautan grup disalin.')}catch{say('Salin alamat: '+link)}});
$('gmTabMembers').addEventListener('click',()=>{$('gmTabMembers').classList.add('active');$('gmTabLinks').classList.remove('active');$('gmInfoMembersArea').hidden=false;$('gmInfoLinksArea').hidden=true;void loadMembers()});
$('gmTabLinks').addEventListener('click',()=>{$('gmTabLinks').classList.add('active');$('gmTabMembers').classList.remove('active');$('gmInfoMembersArea').hidden=true;$('gmInfoLinksArea').hidden=false});
$('gmMessageSearchToggle').addEventListener('click',()=>{const b=$('gmMessageSearchBox');b.hidden=!b.hidden;if(!b.hidden)$('gmMessageQuery').focus();else{$('gmMessageQuery').value='';renderMessages()}});
$('gmMessageSearchClear').addEventListener('click',()=>{$('gmMessageQuery').value='';$('gmMessageSearchBox').hidden=true;renderMessages()});$('gmMessageQuery').addEventListener('input',renderMessages);
$('gmEditForm').addEventListener('submit',async e=>{e.preventDefault();const ok=await groupAction('/groups/update',{groupId:state.active,name:$('gmEditName').value.trim(),description:$('gmEditDesc').value.trim()});if(ok){say('Informasi grup diperbarui.');closeGroupInfo()}});
$('gmCloseGroup').addEventListener('click',async()=>{if(!state.active||!confirm('Tutup grup ini? Anggota tidak lagi dapat mengaksesnya.'))return;const id=state.active;
  try{await api('/groups/close','POST',{groupId:id});if(id===state.active){state.selectSeq++;clearAccess();state.active=null;state.group=null;$('gmRoom').hidden=true;$('gmEmpty').hidden=false;$('gmApp').classList.remove('room-open');closeGroupInfo()}await refreshList();say('Grup ditutup.')}
  catch(e){say(e.message)}});
$('gmLeave').addEventListener('click',async()=>{const id=state.active;if(!id||!confirm('Tinggalkan grup ini?'))return;try{await api('/groups/leave','POST',{groupId:id});closeGroupInfo();await refreshList();if(id===state.active)await selectGroup(id,true);say('Anda sudah keluar dari grup.')}catch(e){say(e.message)}});
$('gmUnpin').addEventListener('click',()=>groupAction('/groups/pin',{groupId:state.active,messageId:null}));
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!document.querySelector('dialog[open]')){closePicker();closeGroupInfo()}});
function newClientId(){if(crypto.randomUUID)return crypto.randomUUID();return '10000000-1000-4000-8000-100000000000'.replace(/[018]/g,c=>(c^crypto.getRandomValues(new Uint8Array(1))[0]&15>>c/4).toString(16))}
async function preparePhoto(file,purpose){
 if(!file||!['image/jpeg','image/png','image/webp'].includes(file.type))throw Error('Pilih foto JPG, PNG, atau WebP.');
 const max=purpose==='avatar'?2*1024*1024:5*1024*1024;if(file.size>max)throw Error('Ukuran foto maksimal '+max/1024/1024+' MB.');
 const bitmap=await createImageBitmap(file).catch(()=>{throw Error('Foto tidak dapat dibuka. Pilih file lain.');});
 try{if(bitmap.width*bitmap.height>16000000||bitmap.width>8192||bitmap.height>8192)throw Error('Foto maksimal 16 megapiksel.');
  const canvas=document.createElement('canvas'),side=purpose==='avatar'?768:1920;
  if(purpose==='avatar'){canvas.width=canvas.height=Math.min(side,bitmap.width,bitmap.height)}else{const scale=Math.min(1,side/Math.max(bitmap.width,bitmap.height));canvas.width=Math.max(1,Math.round(bitmap.width*scale));canvas.height=Math.max(1,Math.round(bitmap.height*scale))}
  const ctx=canvas.getContext('2d');if(!ctx)throw Error('Browser belum mendukung pemrosesan foto.');ctx.fillStyle='#ffffff';ctx.fillRect(0,0,canvas.width,canvas.height);
  if(purpose==='avatar'){const n=Math.min(bitmap.width,bitmap.height);ctx.drawImage(bitmap,(bitmap.width-n)/2,(bitmap.height-n)/2,n,n,0,0,canvas.width,canvas.height)}else ctx.drawImage(bitmap,0,0,canvas.width,canvas.height);
  const blob=await new Promise((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(Error('Foto gagal diproses.')),'image/jpeg',.88));
  if(blob.size>max)throw Error('Foto terlalu besar setelah diproses.');return blob;
 }finally{bitmap.close()}
}
async function uploadPhoto(groupId,purpose,blob,filename=null,mime=null){const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),45000);
 try{const r=await fetch('/api/trader-connect/groups/upload?groupId='+encodeURIComponent(groupId)+'&purpose='+purpose,{method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':mime||blob.type,'X-MarketMarney-Request':'1',...(filename?{'X-File-Name':encodeURIComponent(filename)}:{})},body:blob,signal:controller.signal});const data=await r.json().catch(()=>({}));if(!r.ok)throw Object.assign(Error(data.error||'Lampiran gagal diunggah.'),{status:r.status});return data}
 catch(e){if(e.name==='AbortError')throw Error('Unggah lampiran terlalu lama. Coba kembali.');throw e}finally{clearTimeout(timer)}
}
function closePicker(){$('gmAttachmentPicker').hidden=true;$('gmAttach').setAttribute('aria-expanded','false')}
$('gmAttach').addEventListener('click',()=>{const closed=$('gmAttachmentPicker').hidden;$('gmAttachmentPicker').hidden=!closed;$('gmAttach').setAttribute('aria-expanded',String(closed))});
$('gmPickPhoto').addEventListener('click',()=>{closePicker();$('gmPhotoFile').click()});
$('gmPickFile').addEventListener('click',()=>{closePicker();$('gmDocumentFile').click()});
const documentTypes={pdf:'application/pdf',docx:'application/vnd.openxmlformats-officedocument.wordprocessingml.document',xlsx:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',pptx:'application/vnd.openxmlformats-officedocument.presentationml.presentation',txt:'text/plain',csv:'text/csv',md:'text/markdown',json:'application/json'};
$('gmDocumentFile').addEventListener('change',()=>{const f=$('gmDocumentFile').files[0],id=state.active;$('gmDocumentFile').value='';if(!f||!id||state.sending.has(id)||!state.group?.joined)return;const ext=f.name.split('.').pop().toLowerCase();if(!Object.hasOwn(documentTypes,ext)){say('Pilih PDF, DOCX, XLSX, PPTX, TXT, CSV, MD, atau JSON.');return}if(!f.size||f.size>10*1024*1024){say('Ukuran dokumen harus 1 byte hingga 10 MB.');return}state.photoSeq++;clearImage(id);clearFile(id);mediaDraft(id).file={blob:f,name:f.name,mime:documentTypes[ext],extension:ext,mediaId:null};renderComposer();$('gmBody').focus()});
$('gmFileCancel').addEventListener('click',()=>{clearFile(state.active);renderComposer()});
$('gmPhotoFile').addEventListener('change',async()=>{const file=$('gmPhotoFile').files[0],id=state.active,seq=++state.photoSeq;$('gmPhotoFile').value='';if(!file||!id)return;$('gmComposeStatus').textContent='Menyiapkan foto…';
 try{const blob=await preparePhoto(file,'message');if(seq!==state.photoSeq||id!==state.active||!state.group?.joined)return;clearImage(id);clearFile(id);mediaDraft(id).image={blob,url:URL.createObjectURL(blob),mediaId:null};renderComposer()}
 catch(e){if(seq===state.photoSeq)say(e.message)}finally{if(seq===state.photoSeq&&id===state.active)renderComposer()}
});
$('gmPhotoCancel').addEventListener('click',()=>{state.photoSeq++;clearImage(state.active);renderComposer()});
$('gmReplyCancel').addEventListener('click',()=>{mediaDraft().reply=null;mediaDraft().attempt=null;renderComposer();$('gmBody').focus()});
$('gmImageClose').addEventListener('click',closeImage);$('gmImageViewer').addEventListener('close',()=>$('gmImageFull').removeAttribute('src'));
$('gmAvatarChoose').addEventListener('click',()=>$('gmAvatarFile').click());
function closeAvatar(){if(state.avatarBusy)return;if($('gmPhotoDialog').open)$('gmPhotoDialog').close();if(state.avatarDraft?.url)URL.revokeObjectURL(state.avatarDraft.url);state.avatarDraft=null;$('gmAvatarPreview').removeAttribute('src')}
$('gmAvatarFile').addEventListener('change',async()=>{const file=$('gmAvatarFile').files[0],groupId=state.active,seq=++state.avatarSeq;$('gmAvatarFile').value='';if(!file||!state.group?.canEditPhoto)return;
 try{const blob=await preparePhoto(file,'avatar');if(seq!==state.avatarSeq||state.active!==groupId||!state.group?.canEditPhoto)return;closeAvatar();state.avatarDraft={blob,url:URL.createObjectURL(blob),groupId,mediaId:null};$('gmAvatarPreview').src=state.avatarDraft.url;$('gmAvatarStatus').textContent='';$('gmPhotoDialog').showModal()}
 catch(e){say(e.message)}});
$('gmAvatarCancel').addEventListener('click',closeAvatar);$('gmPhotoDialog').addEventListener('cancel',e=>{if(state.avatarBusy)e.preventDefault();else closeAvatar()});
$('gmAvatarForm').addEventListener('submit',async e=>{e.preventDefault();const d=state.avatarDraft;if(!d||state.avatarBusy||d.groupId!==state.active)return;state.avatarBusy=true;$('gmAvatarSave').disabled=true;$('gmAvatarCancel').disabled=true;$('gmAvatarStatus').textContent='Menyimpan foto…';
 try{if(!d.mediaId)d.mediaId=(await uploadPhoto(d.groupId,'avatar',d.blob)).mediaId;await api('/groups/avatar','POST',{groupId:d.groupId,mediaId:d.mediaId});state.avatarBusy=false;closeAvatar();say('Foto profil grup diperbarui.');await refreshList();if(state.active===d.groupId)await selectGroup(d.groupId,true)}
 catch(e){$('gmAvatarStatus').textContent=e.message}finally{state.avatarBusy=false;$('gmAvatarSave').disabled=false;$('gmAvatarCancel').disabled=false}});
$('gmAvatarRemove').addEventListener('click',async()=>{const id=state.active;if(!id||!confirm('Hapus foto profil grup? Pesan dan anggota tetap tersimpan.'))return;$('gmAvatarRemove').disabled=true;
 try{if(await groupAction('/groups/avatar',{groupId:id,mediaId:null}))say('Foto profil grup dihapus.')}
 finally{$('gmAvatarRemove').disabled=false}});
window.addEventListener('pagehide',()=>{for(const id of state.mediaDrafts.keys())clearMediaDraft(id);closeAvatar();closeImage()});
async function poll(){if(window.__mm45Suspended||document.hidden||navigator.onLine===false||!state.active||state.actionBusy)return;const id=state.active;await selectGroup(id,true);if(state.active===id&&state.infoOpen&&state.group?.joined&&state.roster.length<=50)await loadMembers()}
async function boot(){useTheme();const s=await fetch('/api/community/status',{credentials:'same-origin',cache:'no-store'}).then(r=>r.json()).catch(()=>({}));
  if(!s.user){$('gmGuest').hidden=false;return}state.me=s.user;$('gmApp').hidden=false;const id=new URLSearchParams(location.search).get('group');
  if(id&&/^[0-9a-f-]{36}$/.test(id)){
    // Sidebar and protected room can load together; lists never authorize access.
    void refreshList().catch(e=>say(e.message));
    await selectGroup(id);
  }else{await refreshList();if(state.mine.length)await selectGroup(state.mine[0].id);}
  let polling=false;setInterval(async()=>{if(polling)return;polling=true;try{await poll()}finally{polling=false}},8500);
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)void poll()});
  window.addEventListener('mm45:resume',()=>{void poll()});
}
boot().catch(e=>say(e.message));
})();
