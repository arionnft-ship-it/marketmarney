(()=>{'use strict';
const make=(tag,cls,text)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n};
const eligible='#shMsgText,#shDmBody,#gmBody,#mm1831-text,#shBody,.sh-comment-form input,.mm1828-reply-form textarea,textarea[id^="mm1828-text-"],#replyText,#newBody';
const EMOJI=[['😀','Senyum'],['😊','Senang'],['😄','Gembira'],['😂','Tertawa'],['🤣','Tertawa lepas'],['😍','Suka sekali'],['🥰','Sayang'],['😎','Keren'],['🤔','Berpikir'],['😮','Terkejut'],['😢','Sedih'],['😭','Menangis'],['😅','Lega'],['😉','Kedip'],['🥳','Merayakan'],['😴','Mengantuk'],['👍','Setuju'],['👎','Tidak setuju'],['👏','Tepuk tangan'],['🙌','Hore'],['🙏','Terima kasih'],['🤝','Sepakat'],['💪','Semangat'],['👀','Mengamati'],['❤️','Hati'],['💙','Hati biru'],['💛','Hati emas'],['💯','Seratus'],['🔥','Api'],['✨','Bintang'],['🎉','Perayaan'],['✅','Selesai'],['❌','Batal'],['⚠️','Perhatian'],['💡','Ide'],['📌','Sematan'],['📈','Grafik naik'],['📉','Grafik turun'],['📊','Analisis'],['📝','Catatan'],['🎯','Target'],['⏰','Waktu'],['💰','Uang'],['🪙','Koin'],['☕','Kopi'],['🚀','Roket'],['🌍','Dunia'],['🏆','Piala']];
const REACTIONS=[['👍','Suka'],['❤️','Suka sekali'],['😂','Tertawa'],['😮','Terkejut'],['😢','Sedih'],['🔥','Semangat']];
let picker,target=null,selection=null,opener=null,search,grid,pickerStatus,returnInput=null;
function closePicker(){if(picker?.open)picker.close();}
function initPicker(){if(picker)return;
 picker=make('dialog','mm-emoji-dialog');picker.id='mmEmojiPicker1877';picker.setAttribute('aria-labelledby','mmEmojiTitle1877');
 const head=make('div','mm-interaction-head'),title=make('h2','','Pilih emoji');title.id='mmEmojiTitle1877';const close=make('button','mm-interaction-close','×');close.type='button';close.setAttribute('aria-label','Tutup pilihan emoji');close.addEventListener('click',closePicker);head.append(title,close);
 const label=make('label','mm-emoji-search');label.append(make('span','','Cari emoji'));search=make('input');search.type='search';search.placeholder='Cari senyum, hati, grafik…';search.setAttribute('aria-label','Cari emoji');label.append(search);
 grid=make('div','mm-emoji-grid');grid.setAttribute('role','group');grid.setAttribute('aria-label','Pilihan emoji');pickerStatus=make('p','mm-interaction-status');pickerStatus.setAttribute('role','status');
 const hint=make('p','mm-interaction-hint','Emoji ditambahkan ke pesan, tidak langsung dikirim.');picker.append(head,label,grid,pickerStatus,hint);document.body.append(picker);
 function render(){const q=search.value.trim().toLocaleLowerCase('id');grid.replaceChildren();for(const [symbol,name]of EMOJI.filter(x=>x.join(' ').toLocaleLowerCase('id').includes(q))){const b=make('button','mm-emoji-choice',symbol);b.type='button';b.title=name;b.setAttribute('aria-label',name+' '+symbol);b.addEventListener('click',()=>insert(symbol));grid.append(b)}if(!grid.children.length)grid.append(make('p','mm-interaction-hint','Emoji tidak ditemukan.'));}
 picker.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();e.stopPropagation();closePicker();}},true);search.addEventListener('input',render);picker.addEventListener('close',()=>{if(picker.open)return;const n=returnInput||opener;target=null;selection=null;opener=null;returnInput=null;if(n?.isConnected)n.focus({preventScroll:true});});
 picker.addEventListener('click',e=>{if(e.target===picker){const r=picker.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)closePicker();}});picker.render=render;
}
function insert(symbol){const input=target;if(!input?.isConnected||input.disabled||input.readOnly||!input.getClientRects().length){pickerStatus.textContent='Kolom pesan tidak tersedia.';return;}
 const start=Math.min(selection?.start??input.value.length,input.value.length),end=Math.max(start,Math.min(selection?.end??start,input.value.length));
 if(input.maxLength>=0&&input.value.length-(end-start)+symbol.length>input.maxLength){pickerStatus.textContent='Pesan mencapai batas karakter. Hapus sebagian teks terlebih dahulu.';return;}
 input.setRangeText(symbol,start,end,'end');input.dispatchEvent(new Event('input',{bubbles:true}));returnInput=input;closePicker();input.focus({preventScroll:true});
}
const attached=new WeakMap();
function attach(input){if(attached.has(input)||!input.matches?.(eligible))return;const b=make('button','mm-emoji-trigger','☺');b.type='button';b.title='Tambahkan emoji';b.setAttribute('aria-label','Tambahkan emoji');b.setAttribute('aria-haspopup','dialog');b.dataset.emojiFor=input.id||'pesan';
 b.addEventListener('click',()=>{if(input.disabled||input.readOnly)return;initPicker();returnInput=null;target=input;selection={start:input.selectionStart,end:input.selectionEnd};opener=b;search.value='';pickerStatus.textContent='';picker.render();picker.showModal();search.focus();});input.after(b);attached.set(input,b);input.parentElement?.classList.add('mm-has-emoji');
}
function scan(root){if(root.nodeType!==1&&root.nodeType!==9)return;if(root.matches?.(eligible))attach(root);root.querySelectorAll?.(eligible).forEach(attach);}
function boot(){scan(document.body);const pending=new Set();let queued=false;new MutationObserver(ms=>{for(const m of ms)for(const n of m.addedNodes)if(n.nodeType===1)pending.add(n);if(!queued&&pending.size){queued=true;queueMicrotask(()=>{queued=false;const nodes=[...pending];pending.clear();nodes.forEach(n=>{if(n.isConnected)scan(n)})})}}).observe(document.body,{subtree:true,childList:true});}
window.Emoji1877={attach,scan};

// Reaction summaries never invent counts. The server owns the selected reaction.
const records=new Map();let reactionDialog,activeReaction=null,reactionOpener=null;
function setupReactions(){if(reactionDialog)return;reactionDialog=make('dialog','mm-reaction-dialog');reactionDialog.id='mmReactionPicker1877';reactionDialog.setAttribute('aria-labelledby','mmReactionTitle1877');
 const head=make('div','mm-interaction-head'),title=make('h2','','Pilih reaksi');title.id='mmReactionTitle1877';const close=make('button','mm-interaction-close','×');close.type='button';close.setAttribute('aria-label','Tutup reaksi');close.addEventListener('click',()=>reactionDialog.close());head.append(title,close);
 const choices=make('div','mm-reaction-choices');choices.setAttribute('role','group');choices.setAttribute('aria-label','Pilihan reaksi');for(const [emoji,label]of REACTIONS){const b=make('button','mm-reaction-choice');b.type='button';b.dataset.reactionEmoji=emoji;b.setAttribute('aria-label',label+' '+emoji);b.append(make('span','',emoji),make('small','',label));b.addEventListener('click',()=>{const rec=activeReaction;if(rec&&!rec.busy)void save(rec,rec.data.mine===emoji?null:emoji)});choices.append(b);}
 const status=make('p','mm-interaction-status');status.setAttribute('role','status');status.id='mmReactionStatus1877';reactionDialog.append(head,choices,make('p','mm-interaction-hint','Satu reaksi per akun. Pilih reaksi yang sama untuk membatalkan.'),status);document.body.append(reactionDialog);
 reactionDialog.addEventListener('close',()=>{if(reactionDialog.open)return;activeReaction=null;const n=reactionOpener;reactionOpener=null;if(n?.isConnected)n.focus({preventScroll:true});});
 reactionDialog.addEventListener('click',e=>{if(e.target===reactionDialog){const r=reactionDialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)reactionDialog.close();}});
}
function modalState(rec){if(activeReaction!==rec||!reactionDialog?.open)return;reactionDialog.querySelectorAll('[data-reaction-emoji]').forEach(b=>{b.disabled=rec.busy;b.setAttribute('aria-pressed',String(rec.data.mine===b.dataset.reactionEmoji));});document.getElementById('mmReactionStatus1877').textContent=rec.busy?'Menyimpan reaksi…':rec.error||'';}
function redraw(rec){for(const view of [...rec.views]){if(!view.host.isConnected&&view.rendered){rec.views.delete(view);continue;}const {host,summary,trigger,status}=view;summary.replaceChildren();for(const item of rec.data.items||[]){if(!REACTIONS.some(x=>x[0]===item.emoji)||!(item.count>0))continue;const chip=make('button','mm-reaction-chip',item.emoji+' '+item.count);chip.type='button';chip.setAttribute('aria-label',item.emoji+' · '+item.count+' reaksi'+(item.emoji===rec.data.mine?' · reaksi Anda':''));chip.setAttribute('aria-pressed',String(item.emoji===rec.data.mine));chip.disabled=rec.busy;chip.addEventListener('click',()=>save(rec,rec.data.mine===item.emoji?null:item.emoji));summary.append(chip);}
 trigger.textContent=rec.data.mine?'Ubah reaksi':'☺ Reaksi';trigger.disabled=rec.busy;trigger.setAttribute('aria-label',rec.data.mine?'Ubah reaksi Anda':'Beri reaksi');status.textContent=rec.error||'';host.dataset.reactionTotal=String(rec.data.total||0);view.rendered=host.isConnected;}
 modalState(rec);}
async function save(rec,emoji){if(rec.busy)return;rec.busy=true;rec.error='';redraw(rec);const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),12000);
 try{const group=rec.kind==='group';const res=await fetch(group?'/api/trader-connect/groups/reaction':'/api/trader-profiles/reaction',{method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json','X-MarketMarney-Request':'1'},body:JSON.stringify(group?{groupId:rec.groupId,messageId:rec.id,emoji}:{id:rec.id,emoji}),signal:controller.signal});const data=await res.json();if(!res.ok)throw Error(data.error||'Reaksi belum tersimpan.');rec.data=data.reactions;
 for(const v of rec.views)if(v.host.isConnected)v.onChange?.(rec.data);if(activeReaction===rec)reactionDialog.close();
 }catch(e){rec.error=e.name==='AbortError'?'Hasil belum diketahui. Muat ulang percakapan sebelum mencoba lagi.':e.message||'Reaksi gagal disimpan.';}
 finally{clearTimeout(timer);rec.busy=false;redraw(rec);}
}
function mount(host,opts){const key=opts.kind+':'+(opts.groupId||'')+':'+opts.id;let rec=records.get(key);const blank={items:[],mine:null,total:0};if(!rec){rec={...opts,data:opts.initial||blank,busy:false,error:'',views:new Set()};records.set(key,rec);}else if(!rec.busy)rec.data=opts.initial||blank;
 host.classList.add('mm-reactions');host.dataset.reactionId=opts.id;host.dataset.reactionKind=opts.kind;host.replaceChildren();const summary=make('span','mm-reaction-summary'),trigger=make('button','mm-reaction-trigger'),status=make('span','mm-reaction-status');trigger.type='button';trigger.setAttribute('aria-haspopup','dialog');status.setAttribute('role','status');
 trigger.addEventListener('click',()=>{setupReactions();activeReaction=rec;reactionOpener=trigger;reactionDialog.showModal();modalState(rec);reactionDialog.querySelector('[data-reaction-emoji]')?.focus();});host.append(summary,trigger,status);rec.views.add({host,summary,trigger,status,onChange:opts.onChange,rendered:false});redraw(rec);
 if(records.size>500)for(const [key,r]of records)if(!r.busy&&[...r.views].every(v=>!v.host.isConnected)&&r!==activeReaction)records.delete(key);
 return {update:data=>{if(!rec.busy){rec.data=data;redraw(rec)}}};
}
window.SocialReactions1877={mount};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
})();
