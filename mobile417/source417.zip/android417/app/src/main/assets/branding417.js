(function () {
  'use strict';
  // WarXAU 7.7 embeds its old corporate mark as data URIs. Change only the
  // verified header and favicon; the arena, feed, chart and game state are untouched.
  if (location.protocol !== 'https:' || location.hostname !== 'marketmarney.com' ||
      (location.port && location.port !== '443') ||
      location.pathname !== '/assets/xau-war-3d.html' ||
      document.title !== 'WarXAU HD LIVE 7.7 | MarketMarney') return;
  var logo = document.querySelector('header.site-header > a.brand[aria-label="Beranda MarketMarney"] > img');
  if (!logo) return;
  var source = '/__android417/brand/logo.png';
  logo.removeAttribute('srcset');
  logo.src = source;
  logo.alt = 'MARNEY';
  logo.style.objectFit = 'contain';
  document.querySelectorAll('head link[rel="icon"]').forEach(function (icon) {
    icon.href = source;
    icon.type = 'image/png';
  });
}());
