(function(root){'use strict';
// User-authored links are buttons until permission is granted. No preview fetching,
// preconnect, URL shortening, or remembered permission; each activation asks again.
function normalize(value){
 if(typeof value!=='string'||value.length>2048||/[\s\p{Cc}\p{Cf}<>"'`]/u.test(value))return null;
 const raw=/^www\./i.test(value)?'https://'+value:value;
 if(!/^https?:\/\//i.test(raw)||/^www\.$/i.test(value))return null;
 try{const u=new URL(raw);if(!['http:','https:'].includes(u.protocol)||!u.hostname||u.username||u.password||u.href.length>4096)return null;return u;}catch{return null;}
}
function trimEnd(raw){
 raw=raw.replace(/[.,;:!?]+$/g,'');
 for(let again=true;again;){again=false;for(const [l,r] of [['(',')'],['[',']'],['{','}']]){
  const count=c=>raw.split(c).length-1;
  if(raw.endsWith(r)&&count(r)>count(l)){raw=raw.slice(0,-1).replace(/[.,;:!?]+$/g,'');again=true;}
 }}return raw;
}
function urls(value){
 const source=String(value??''),out=[];
 for(const m of source.matchAll(/(?:https?:\/\/|www\.)[^\s<>"'`]+/gi)){
  // Avoid turning the suffix of an e-mail/identifier into a link.
  if(m.index>0&&/[\p{L}\p{N}_@]/u.test(source[m.index-1]))continue;
  const text=trimEnd(m[0]),u=normalize(text);if(u)out.push({index:m.index,text,url:u.href,host:u.hostname});
 }return out;
}
if(typeof module==='object'&&module.exports){module.exports={urls,normalize};return;}
const doc=root.document;if(!doc)return;
const make=(tag,cls,value)=>{const n=doc.createElement(tag);if(cls)n.className=cls;if(value!==undefined)n.textContent=value;return n;};
let dialog,domain,address,warning,continueLink,cancelButton,pending=null,opener=null;
function setup(){if(dialog)return;
 dialog=make('dialog','sm-link-dialog');dialog.id='smLinkConsent';dialog.setAttribute('aria-labelledby','smLinkTitle');dialog.setAttribute('aria-describedby','smLinkDescription smLinkWarning');
 const head=make('div','sm-link-head'),icon=make('span','sm-link-icon','↗');icon.setAttribute('aria-hidden','true');
 head.append(icon,make('span','sm-link-kicker','SOCIAL MARNEY · TAUTAN PENGGUNA'));
 const title=make('h2','','Buka tautan ini?');title.id='smLinkTitle';
 const desc=make('p','sm-link-description','Tautan ini dibagikan oleh pengguna. Periksa alamat tujuan sebelum melanjutkan.');desc.id='smLinkDescription';
 const destination=make('div','sm-link-destination');destination.append(make('small','','ALAMAT TUJUAN'));domain=make('strong','sm-link-domain');address=make('p','sm-link-address');destination.append(domain,address);
 warning=make('p','sm-link-warning');warning.id='smLinkWarning';
 const actions=make('div','sm-link-actions');cancelButton=make('button','sm-link-cancel','Batal');cancelButton.type='button';cancelButton.autofocus=true;cancelButton.addEventListener('click',()=>dialog.close('cancel'));
 continueLink=make('a','sm-link-continue','Buka tautan ↗');continueLink.target='_blank';continueLink.rel='noopener noreferrer nofollow ugc';continueLink.referrerPolicy='no-referrer';
 continueLink.addEventListener('click',e=>{if(!pending||continueLink.href!==pending){e.preventDefault();return;}dialog.close('confirmed');});
 actions.append(cancelButton,continueLink);dialog.append(head,title,desc,destination,warning,actions);doc.body.append(dialog);
 dialog.addEventListener('close',()=>{if(dialog.open)return;pending=null;continueLink.removeAttribute('href');domain.textContent='';address.textContent='';if(opener?.isConnected)opener.focus({preventScroll:true});opener=null;});
 dialog.addEventListener('click',e=>{if(e.target!==dialog)return;const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)dialog.close('cancel');});
}
function ask(value,trigger){const u=normalize(value);if(!u)return false;setup();if(dialog.open)return false;
 pending=u.href;opener=trigger||doc.activeElement;domain.textContent=u.host;address.textContent=u.href;
 warning.textContent=(u.protocol==='http:'?'Alamat ini menggunakan HTTP, bukan HTTPS. ':'')+'Tautan belum diperiksa keamanannya. Ceklis pemilik atau komunitas bukan jaminan keamanan tautan.';
 continueLink.href=u.href;
 try{dialog.showModal();cancelButton.focus({preventScroll:true});return true;}catch{pending=null;continueLink.removeAttribute('href');return false;}
}
function text(node,value){const source=String(value??'');node.replaceChildren();let end=0;
 for(const u of urls(source)){node.append(doc.createTextNode(source.slice(end,u.index)));const button=make('button','sm-shared-link',u.text);button.type='button';button.dataset.smSharedUrl=u.url;button.setAttribute('aria-haspopup','dialog');button.setAttribute('aria-label','Buka tautan dengan konfirmasi: '+u.text);button.title='Periksa tautan · '+u.host;node.append(button);end=u.index+u.text.length;}
 node.append(doc.createTextNode(source.slice(end)));return node;
}
doc.addEventListener('click',e=>{const trigger=e.target.closest?.('button[data-sm-shared-url]');if(!trigger)return;e.preventDefault();e.stopPropagation();ask(trigger.dataset.smSharedUrl,trigger);});
root.SocialLinks1876={urls,normalize,text,ask};
})(typeof window==='undefined'?globalThis:window);
