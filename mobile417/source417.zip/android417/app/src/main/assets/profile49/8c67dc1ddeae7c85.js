/* v18.8.0 — bounded, on-screen video posters. Never seeks/plays the visible player.
   No persistent storage, no upload, no background requests to arbitrary video origins. */
(()=>{'use strict';
 const FALLBACK='/assets/video-placeholder1880.svg',MAX_CACHE=48;
 const states=new WeakMap(), cache=new Map(),pending=new Map(),queue=[];
 let busy=false,observer;
 const saveData=()=>!!navigator.connection?.saveData;
 function safeSource(raw){
  try{const u=new URL(raw,location.href);if(u.origin!==location.origin||u.username||u.password)return '';
   return u.protocol==='blob:'||(/^https?:$/.test(u.protocol)&&/^\/media\/[0-9a-f-]{36}\.mp4$/.test(u.pathname))?u.href:'';
  }catch{return '';}
 }
 function source(el){return el.tagName==='VIDEO'?(el.getAttribute('src')||el.querySelector('source')?.getAttribute('src')||''):el.dataset.mmVideoThumb||'';}
 function remember(key,value){cache.delete(key);cache.set(key,value);while(cache.size>MAX_CACHE)cache.delete(cache.keys().next().value);}
 function frame(video){
  if(video.readyState<2||!video.videoWidth||!video.videoHeight)return '';
  const canvas=document.createElement('canvas'),ratio=Math.min(1,640/video.videoWidth,640/video.videoHeight);
  canvas.width=Math.max(1,Math.round(video.videoWidth*ratio));canvas.height=Math.max(1,Math.round(video.videoHeight*ratio));
  const ctx=canvas.getContext('2d');if(!ctx)return '';ctx.drawImage(video,0,0,canvas.width,canvas.height);
  return canvas.toDataURL('image/jpeg',.78);
 }
 function extract(url){return new Promise(resolve=>{
  const v=document.createElement('video');let done=false,seeked=false;
  v.muted=true;v.playsInline=true;v.preload='auto';
  const finish=value=>{if(done)return;done=true;clearTimeout(timer);v.onloadedmetadata=v.onloadeddata=v.onseeked=v.onerror=null;v.removeAttribute('src');v.load();resolve(value||'');};
  const capture=()=>{try{finish(frame(v));}catch{finish('');}};
  const timer=setTimeout(()=>finish(''),8000);
  v.onloadedmetadata=()=>{const target=Number.isFinite(v.duration)&&v.duration>0?Math.min(.6,v.duration/4):0;
   if(target>0){seeked=true;try{v.currentTime=target;}catch{seeked=false;}}};
  v.onloadeddata=()=>{if(!seeked)capture();};v.onseeked=capture;v.onerror=()=>finish('');v.src=url;v.load();
 });}
 async function pump(){if(busy||document.hidden||saveData())return;busy=true;
  try{while(queue.length&&!document.hidden&&!saveData()){
   const task=queue.shift();let value='';try{value=await extract(task.url);}catch{}
   if(value)remember(task.url,value);pending.delete(task.url);task.resolve(value);
  }}finally{busy=false;}}
 function thumbnail(url){if(cache.has(url))return Promise.resolve(cache.get(url));if(pending.has(url))return pending.get(url);
  if(queue.length>=40)return Promise.resolve('');
  const promise=new Promise(resolve=>queue.push({url,resolve}));pending.set(url,promise);void pump();return promise;}
 function apply(el,value){if(el.tagName==='VIDEO')el.poster=value;else el.src=value;}
 async function prepare(el){const st=states.get(el);if(!st||st.started||st.custom||!el.isConnected||saveData())return;
  const rect=el.getBoundingClientRect();if(!rect.width||!rect.height)return;
  const url=safeSource(st.raw);if(!url)return;st.started=true;
  const poster=await thumbnail(url);if(poster&&el.isConnected&&states.get(el)===st&&source(el)===st.raw){apply(el,poster);el.dataset.mmPreview='frame';}}
 function watch(el){
  const raw=source(el),previous=states.get(el);if(previous?.raw===raw)return;
  let supplied=el.tagName==='VIDEO'?el.getAttribute('poster'):el.getAttribute('src');
  // A reused video element must not show the old source's captured frame.
  if(previous&&!previous.custom)supplied='';
  const custom=!!supplied&&supplied!==FALLBACK;
  const state={raw,custom,started:false};states.set(el,state);
  if(!custom){apply(el,FALLBACK);el.dataset.mmPreview='fallback';}else el.dataset.mmPreview='custom';
  if(el.tagName==='VIDEO'){
   el.playsInline=true;
   if(!previous)el.addEventListener('loadeddata',()=>{const now=states.get(el);if(!now||now.custom||!safeSource(now.raw))return;
    try{const p=frame(el);if(p){remember(safeSource(now.raw),p);apply(el,p);el.dataset.mmPreview='frame';}}catch{}});
  }else if(!previous){el.addEventListener('error',()=>{if(el.getAttribute('src')!==FALLBACK){states.get(el).custom=false;apply(el,FALLBACK);el.dataset.mmPreview='fallback';void prepare(el);}});}
  if(!custom){if(observer)observer.observe(el);else void prepare(el);}
 }
 function scan(root=document){if(root.nodeType===1&&root.matches('video,[data-mm-video-thumb]'))watch(root);root.querySelectorAll?.('video,[data-mm-video-thumb]').forEach(watch);}
 function ready(){if('IntersectionObserver' in window)observer=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting)void prepare(e.target);}),{rootMargin:'180px 0px'});
  scan();new MutationObserver(records=>{for(const r of records){if(r.type==='attributes'){if(r.target.matches('video,[data-mm-video-thumb]'))watch(r.target);else if(r.target.tagName==='SOURCE'&&r.target.closest('video'))watch(r.target.closest('video'));}else r.addedNodes.forEach(n=>{if(n.nodeType===1)scan(n);});}}).observe(document.body,{childList:true,subtree:true,attributes:true,attributeFilter:['src','data-mm-video-thumb']});
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)void pump();});
 }
 window.MMVideoPreviews1880=Object.freeze({scan,fallback:FALLBACK,safeSource});
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',ready,{once:true});else ready();
})();
