(async()=>{'use strict';
const nameOf1873=(u,key='username')=>String(u?.[key==='username'?'displayName':key+'DisplayName']||u?.[key]||'Trader');

const area=document.querySelector('[data-mm36]');if(!area)return;
const $=id=>document.getElementById(id);let me=null,photoUrl=null,profileLoaded=false,reloadSequence=0,sessionEpoch=0,saving=false,publishing=false,photoUploading=false,avatarUploading=false,postRevision=0;
const date=ms=>new Date(ms).toLocaleString('id-ID',{dateStyle:'medium',timeStyle:'short'});
const create=(tag,cls,text)=>{const e=document.createElement(tag);if(cls)e.className=cls;if(text!==undefined)e.textContent=text;return e};
const api=async(route,method='GET',payload,type='application/json')=>{const headers={};const opts={method,credentials:'same-origin',cache:'no-store'};if(method!=='GET'){headers['X-MarketMarney-Request']='1';headers['Content-Type']=type;opts.body=type==='application/json'?JSON.stringify(payload||{}):payload;opts.headers=headers}const r=await fetch('/api/trader-profiles/'+route,opts);const data=await r.json().catch(()=>({}));if(!r.ok)throw Object.assign(Error(data.error||'Permintaan gagal ('+r.status+')'),{status:r.status});return data};
const status=(id,msg,bad=false)=>{const e=$(id);if(!e)return;e.textContent=msg;e.classList.toggle('error',bad)};
const avatar=(el,url,name)=>{el.textContent='';if(url){const img=create('img');img.src=url;img.alt='Foto profil '+name;img.loading='lazy';el.append(img)}else el.textContent=String(name||'?').slice(0,2).toUpperCase()};
function showPosts(node,posts,owner=false){node.replaceChildren();if(!posts.length){node.append(create('p','mm36-sub','Belum ada postingan.'));return}posts.forEach(p=>{const box=create('article','mm36-post');box.id='trader-post-'+p.id;if(new URLSearchParams(location.search).get('post')===p.id){box.classList.add('mm36-post-highlight');setTimeout(()=>box.scrollIntoView({behavior:'smooth',block:'center'}),160)}const head=create('div','mm36-row');const a=create('a','',nameOf1873(p));a.href='/profil.html?user='+encodeURIComponent(p.username);window.SocialIdentity1875?.badge(a,p);head.append(a,create('time','',date(p.createdAt)));if(owner&&p.status==='hidden')head.append(create('span','mm36-muted','Disembunyikan admin'));const message=create('p','mm-public-post-body',p.body);window.SocialLinks1876?.text(message,p.body);box.append(head,message);if(p.imageUrl){const im=create('img');im.src=p.imageUrl;im.loading='lazy';im.alt='Foto postingan';box.append(im)}if(p.videoUrl){const vd=create('video');vd.src=p.videoUrl;vd.controls=true;vd.preload='none';vd.poster='/assets/video-placeholder1880.svg';vd.playsInline=true;vd.style.maxWidth='100%';vd.style.borderRadius='10px';vd.style.marginTop='12px';box.append(vd)}const footer=create('div','mm36-row');if(!owner){const discussion=create('a','mm46-message-btn','Lihat diskusi · '+(p.comments||0)+' komentar');discussion.href='/beranda-trader.html?post='+encodeURIComponent(p.id);footer.append(discussion);}if(owner){const del=create('button','alt','Hapus');del.type='button';del.addEventListener('click',async()=>{if(!confirm('Hapus postingan ini?'))return;del.disabled=true;try{await api('posts','DELETE',{id:p.id});await reload()}catch(e){status('mm36PostStatus',e.message,true);del.disabled=false}});footer.append(del)}else if(window.mm36Viewer){const report=create('button','alt','Laporkan');report.addEventListener('click',async()=>{const reason='spam';try{await api('report','POST',{id:p.id,reason});report.textContent='Dilaporkan';report.disabled=true}catch(e){alert(e.message)}});footer.append(report)}box.append(footer);if(p.reactions){const react=create('div');box.append(react);window.SocialReactions1877?.mount(react,{kind:'post',id:p.id,initial:p.reactions,onChange:data=>{p.reactions=data;}});}node.append(box)})}
async function reload(forceFields=false){const seq=++reloadSequence,epoch=sessionEpoch;try{const d=await api('me');if(seq!==reloadSequence||epoch!==sessionEpoch)return;accountNotice('');me=d.profile;const wrap=$('mm36Account');if(wrap)wrap.hidden=false;avatar($('mm36MyAvatar'),me.avatarUrl,nameOf1873(me));$('mm36Handle').textContent=nameOf1873(me);window.SocialIdentity1875?.badge($('mm36Handle'),me);let progress=$('mm75CommunityProgress');if(!progress){progress=create('p','mm-community-progress');progress.id='mm75CommunityProgress';$('mm36Handle').parentNode.append(progress);}const followers=me.communityBadge?.followers||0;progress.textContent=me.communityBadge?.eligible?'Lencana komunitas aktif · 1.000+ pengikut. Bukan verifikasi identitas.':'Lencana komunitas: '+new Intl.NumberFormat('id-ID').format(followers)+' / 1.000 pengikut aktif.';if(forceFields||!profileLoaded){$('mm36Bio').value=me.bio;$('mm36DisplayName').value=me.hasDisplayName?me.displayName:'';}profileLoaded=true;$('mm36ProfileLink').href='/profil.html?user='+encodeURIComponent(me.username);showPosts($('mm36MyPosts'),d.posts,true);document.dispatchEvent(new CustomEvent('mm80-profile-loaded',{detail:{profile:me,posts:d.posts.length}}))}catch(e){if(seq!==reloadSequence||epoch!==sessionEpoch)return;if(e.status===401){profileLoaded=false;me=null;if($('mm36Account'))$('mm36Account').hidden=true;}else {status('mm36BioStatus','Profil belum dapat dimuat. '+e.message,true);accountNotice('Profil belum dapat dimuat. Periksa koneksi lalu coba lagi.');}}}

function accountNotice(message){const n=$('mm81AccountNotice');if(!n)return;n.hidden=!message;$('mm81AccountNoticeText').textContent=message;}
function controls(){
 const publish=$('mm36Publish');if(publish){publish.disabled=publishing||photoUploading;publish.textContent=publishing?'Mengirim…':photoUploading?'Menunggu foto…':'Terbitkan postingan';}
 if($('mm36PostPhoto'))$('mm36PostPhoto').disabled=photoUploading||publishing;
 if($('mm36SaveBio')){$('mm36SaveBio').disabled=saving;$('mm36SaveBio').textContent=saving?'Menyimpan…':'Simpan Profil';}
 for(const id of ['mm36Bio','mm36DisplayName'])if($(id))$(id).disabled=saving;
 if($('mm36UploadAvatar'))$('mm36UploadAvatar').disabled=avatarUploading;
 $('mm36Publish')?.closest('.mm80-compose')?.setAttribute('aria-busy',String(publishing||photoUploading));
}
async function initAccount(){
 $('mm36PostBody').addEventListener('input',()=>{postRevision++;});
 $('mm81AccountRetry')?.addEventListener('click',async()=>{const b=$('mm81AccountRetry');b.disabled=true;try{await reload();}finally{b.disabled=false;}});
 $('mm36SaveBio').addEventListener('click',async()=>{
  if(saving)return;const epoch=sessionEpoch,bio=$('mm36Bio').value.trim(),displayName=$('mm36DisplayName').value;saving=true;controls();
  try{await api('me','POST',{bio,displayName});if(epoch!==sessionEpoch)return;status('mm36BioStatus','Nama tampilan dan bio berhasil disimpan.');await reload(true);}
  catch(e){if(epoch===sessionEpoch)status('mm36BioStatus',e.message,true);}
  finally{if(epoch===sessionEpoch){saving=false;controls();}}
 });
 $('mm36UploadAvatar').addEventListener('change',async e=>{
  const file=e.target.files[0];if(!file||avatarUploading)return;const epoch=sessionEpoch;avatarUploading=true;controls();status('mm36BioStatus','Mengunggah foto profil…');
  try{if(file.size>1024*1024)throw Error('Foto profil maksimal 1 MB');await api('image?kind=avatar','POST',file,file.type);if(epoch!==sessionEpoch)return;status('mm36BioStatus','Foto profil berhasil disimpan.');await reload();}
  catch(err){if(epoch===sessionEpoch)status('mm36BioStatus',err.message,true);}
  finally{if(epoch===sessionEpoch){avatarUploading=false;e.target.value='';controls();}}
 });
 $('mm36PostPhoto').addEventListener('change',async e=>{
  const f=e.target.files[0];if(photoUploading||publishing)return;photoUrl=null;if(!f)return;
  const epoch=sessionEpoch;photoUploading=true;controls();status('mm36PostStatus','Mengunggah foto…');
  try{if(f.size>2*1024*1024)throw Error('Foto postingan maksimal 2 MB');const d=await api('image?kind=post','POST',f,f.type);if(epoch!==sessionEpoch)return;photoUrl=d.url;status('mm36PostStatus','Foto siap dilampirkan.');}
  catch(err){if(epoch===sessionEpoch){status('mm36PostStatus',err.message,true);e.target.value='';photoUrl=null;}}
  finally{if(epoch===sessionEpoch){photoUploading=false;controls();}}
 });
 $('mm36Publish').addEventListener('click',async()=>{
  if(publishing||photoUploading)return;const epoch=sessionEpoch,revision=postRevision,body=$('mm36PostBody').value.trim(),imageUrl=photoUrl;
  if(!body&&!imageUrl){status('mm36PostStatus','Tulis pesan atau pilih foto terlebih dahulu.',true);$('mm36PostBody').focus();return;}
  publishing=true;controls();status('mm36PostStatus','Mengirim postingan…');
  try{await api('posts','POST',{body,imageUrl});if(epoch!==sessionEpoch)return;
   if(postRevision===revision)$('mm36PostBody').value='';
   $('mm36PostPhoto').value='';photoUrl=null;
   status('mm36PostStatus',postRevision===revision?'Postingan berhasil diterbitkan.':'Postingan berhasil diterbitkan. Draf baru Anda tetap tersedia.');await reload();
  }catch(e){if(epoch===sessionEpoch)status('mm36PostStatus',e.message+' Draf tetap tersedia. Periksa riwayat sebelum mencoba lagi.',true);}
  finally{if(epoch===sessionEpoch){publishing=false;controls();}}
 });
 await reload();
}
async function initPublic(){const query=new URLSearchParams(location.search);const username=query.get('user');if(!username){$('mm36PublicName').textContent='Postingan Komunitas Trader';$('mm36PublicBio').textContent='Ide trading, analisis, dan pengalaman yang dibagikan para pembaca MarketMarney.';$('mm36PublicCount').textContent='Postingan terbaru';$('mm36PublicAvatar').textContent='MM';try{const d=await api('feed');showPosts($('mm36PublicPosts'),d.items)}catch(e){$('mm36PublicBio').textContent=e.message}return}try{const d=await api('public?user='+encodeURIComponent(username));avatar($('mm36PublicAvatar'),d.profile.avatarUrl,nameOf1873(d.profile));$('mm36PublicName').textContent=nameOf1873(d.profile);window.SocialIdentity1875?.badge($('mm36PublicName'),d.profile);let ownerNote=$('mm76OwnerNote');if(!ownerNote){ownerNote=create('p','sm-owner-explainer');ownerNote.id='mm76OwnerNote';$('mm36PublicCount').after(ownerNote);}ownerNote.hidden=!d.profile.groupOwnerBadge?.eligible;ownerNote.textContent=d.profile.groupOwnerBadge?.eligible?'Ceklis emas · Pemilik grup dengan 999+ anggota aktif. Bukan verifikasi identitas.':'';$('mm36PublicHandle').textContent='@'+d.profile.username;document.title=nameOf1873(d.profile)+' | Social Marney';$('mm36PublicBio').textContent=d.profile.bio||'Belum menulis bio.';$('mm36PublicCount').textContent=d.profile.postsCount+' postingan · bergabung '+date(d.profile.joinedAt);showPosts($('mm36PublicPosts'),d.posts)}catch(e){$('mm36PublicName').textContent='Profil tidak ditemukan';$('mm36PublicBio').textContent=e.message}}
try{const r=await fetch('/api/community/status',{credentials:'same-origin',cache:'no-store'});const d=await r.json();window.mm36Viewer=!!d.user}catch{}
if(area.dataset.mm36==='account'){document.addEventListener('mm80-account-session',e=>{if(!e.detail.user){sessionEpoch++;reloadSequence++;saving=false;publishing=false;photoUploading=false;avatarUploading=false;postRevision++;controls();accountNotice('');status('mm36BioStatus','');status('mm36PostStatus','');profileLoaded=false;me=null;photoUrl=null;['mm36Bio','mm36DisplayName','mm36PostBody','mm36PostPhoto'].forEach(id=>{if($(id))$(id).value=''});$('mm36MyPosts').replaceChildren();area.hidden=true;}});initAccount();document.addEventListener('mm36-account-login',()=>{sessionEpoch++;profileLoaded=false;reload(true);})}else initPublic();
})();
